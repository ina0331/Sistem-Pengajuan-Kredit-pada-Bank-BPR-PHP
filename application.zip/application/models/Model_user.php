<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_user extends CI_Model {

	function getInsert($data)
	{
		$this->db->insert('pemohon', $data);
	} 

	function getUser($id_pemohon)
	{
		$query = $this->db->where('id_pemohon',$id_pemohon)
						  ->get('pemohon');
		return $query->row();
	}

	function verifikasi($key) 
	{
		$data['aktif'] = 'YES';
		$this->db->where('md5(tgl_daftar)',$key) 
				 ->update('pemohon',$data);
		return TRUE;
	}

	function cek_login($user,$pass)
	{
		//masuk menggunakan username atau email
		$query 	= $this->db->where('email', $email)
						   ->or_where('username', $user)
				 		   ->where('password', $password)
				 		   ->get('pemohon');

		$pemohon 	= $query->row();

		// set session
		// jika email ada jalankan query 
		// lain jika 
		// username ada jalankan query
		if($user->email || $user->username || $user->password)
		{
			foreach($query->result() as $row) 
			{
				$data = array(
							  'id'		 => $row->id_pemohon,
	 						  'email' 	 => $row->email,
							  'username' => $row->username,
							  'password' 	 => $row->password
							  );
				$this->session->set_userdata($data);
				redirect(site_url());
			}
		}
		else
		{
			$this->session->set_flashdata('info','Username atau Password salah');
			redirect(site_url());
		}

	}

}

/* End of file Model_user.php */
/* Location: ./application/models/Model_user.php */