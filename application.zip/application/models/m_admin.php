<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_admin extends CI_Model {

	function login($username,$password){
		return $this->db->query("SELECT * FROM admin WHERE username = '$username' AND password='$password' ");
	}

 function get_data($table){
    return $this->db->get($table);
  }

 function get_data2($table,$id_admin){
    $this->db->select('nama_lengkap');
    $this->db->where('id_admin',$id_admin);
    return $this->db->get($table);
  }

   function get_data3($table,$id_admin){
    $this->db->select('fotoprofil');
    $this->db->where('id_admin',$id_admin);
    return $this->db->get($table);
  }

function edit_data($where,$table){
    return $this->db->get_where($table,$where);
    
  }

  function insert_data($data,$table){
    $this->db->insert($table,$data);
  }
  
   public function simpan_data($data)
  {
    //tambah pesanan
    $this->db->insert('pesan', $data);

    //ambil stok produk
    
  }


  function update_data($table,$data,$where){
    $this->db->update($table,$data,$where);
  }

  function delete_data($where,$table){
    $this->db->where($where);
    $this->db->delete($table);
  }
public function kode_otomatis_admin(){
    $this->db->select('right(id_admin,3) as kode', false);
    $this->db->order_by('id_admin','desc');
    $this->db->limit(1);
    $query=$this->db->get('admin');
    if($query->num_rows()<>0){
      $data=$query->row();
      $kode=intval($data->kode)+1;
    }else{
      $kode=1;
    }

    $kodemax=str_pad($kode,3,"0", STR_PAD_LEFT);
    $kodejadi='ADM'.$kodemax;

    return $kodejadi;
  }


} 

?>