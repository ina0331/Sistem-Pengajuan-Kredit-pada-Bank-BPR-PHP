<?php
defined('BASEPATH') or exit('No direct Script access allowed');

class m_user extends CI_Model
{
    function login($username,$password){
    return $this->db->query("SELECT * FROM pemohon WHERE username = '$username' AND password='$password' ");
  } 

  function edit_data($where,$table){
    return $this->db->get_where($table,$where);
  }

   function edit_data2($where,$table){
    $this->db->select('*');
    $this->db->from($table);
    $this->db->join('aplikasi','aplikasi.id_aplikasi = pemohon.id_pemohon ','inner');
    $this->db->where($where);

    return $this->db->get();
  } 
 
 function edit_data4($where,$table){
    $this->db->select('*');
    $this->db->from($table);
    $this->db->join('aplikasi','aplikasi.id_pemohon = pemohon.id_pemohon','inner');
    $this->db->where($where);

    return $this->db->get();
  }

  function get_data($table){
    return $this->db->get($table);
  }

  function get_data2($table,$id_pemohon){
    $this->db->select('nama_lengkap');
    $this->db->where('id_pemohon',$id_pemohon);
    return $this->db->get($table);
  }

  function get_data3($table,$id_pemohon){
    $this->db->select('aktif');
    $this->db->where('id_pemohon',$id_pemohon);
    return $this->db->get($table);
  }

  function insert_data($data,$table){
    $this->db->insert($table,$data);
  }

  function update_data($table,$data,$where){
    $this->db->update($table,$data,$where);
  }

  function delete_data($where,$table){
    $this->db->where($where);
    $this->db->delete($table);
  }

  public function kode_otomatis(){
    $this->db->select('right(id_aplikasi,3) as kode', false);
    $this->db->order_by('id_aplikasi','desc');
    $this->db->limit(1);
    $query=$this->db->get('aplikasi');
    if($query->num_rows()<>0){
      $data=$query->row();
      $kode=intval($data->kode)+1;
    }else{
      $kode=1;
    }

    $kodemax=str_pad($kode,3,"0", STR_PAD_LEFT);
    $kodejadi='PJ'.$kodemax;

    return $kodejadi;
  }

  public function kode_otomatis_berkas(){
    $this->db->select('right(kd_berkas,3) as kode', false);
    $this->db->order_by('kd_berkas','desc');
    $this->db->limit(1);
    $query=$this->db->get('berkas');
    if($query->num_rows()<>0){
      $data=$query->row();
      $kode=intval($data->kode)+1;
    }else{
      $kode=1;
    }

    $kodemax=str_pad($kode,3,"0", STR_PAD_LEFT);
    $kodejadi='BKS'.$kodemax;

    return $kodejadi;
  }

   public function kode_otomatis_pemohon(){
    $this->db->select('right(id_pemohon,3) as kode', false);
    $this->db->order_by('id_pemohon','desc');
    $this->db->limit(1);
    $query=$this->db->get('pemohon');
    if($query->num_rows()<>0){
      $data=$query->row();
      $kode=intval($data->kode)+1;
    }else{
      $kode=1;
    }

    $kodemax=str_pad($kode,3,"0", STR_PAD_LEFT);
    $kodejadi='PMHN20'.$kodemax;

    return $kodejadi;
  }
}
?>