<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	function __construct(){
		parent::__construct();
		
		// cek login
	}

	public function index()
	{
		
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';

		$this->load->view('user/view_index', $data);
	}

	public function login(){
    if($this->session->userdata('id_pemohon') != ""){
      redirect(base_url('Home'));
    }
      $data['judul'] = "Login"; 
      $data['halaman']		= '';
	  $data['judul']			= 'LOGIN';
      $data['header']	= 'user/view_header';
	  $data['footer']	= 'user/view_footer';
	  $data['menu']	= 'user/view_menu';

      $this->load->view('user/view_login',$data);   
  } 

 public function login_proses(){
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));

      // num_rows();jumlah isi data table 
      // row_array(); bongkar satuan data table 
      // result(); bongkar total table

      $cek_login = $this->m_user->login($username,$password)->num_rows();

       
 
      // echo $cek_login;

      if ($cek_login==0){
      	$this->session->set_flashdata('alert','Login Gagal! Username atau Password Salah');
        redirect(base_url('Home/login'));
      }else{
        $data_login = $this->m_user->login($username,$password)->row_array();
        $id_pemohon = $data_login['id_pemohon'];

        $this->session->set_userdata('id_pemohon',$id_pemohon);

        $data_session = $this->m_user->login($username,$password)->row_array();
        // $this->session->set_userdata($id_session);
        redirect(site_url());
      }

    } 

	function item_detail($id_produk)
	{
		$query			= $this->Model_produk->getdata($id_produk);
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		$data['halaman']= 'Detail Produk';
		$data['id_produk'] = $query->id_produk;
		$data['judul']	= $query->judul;
		$data['harga']	= $query->harga;
		$data['isi']	= $query->isi;
		$data['id_kategori'] = $query->id_kategori;
		$data['gambar']	= explode(',', $query->gambar);

		$this->load->view('user/view_itemDetail', $data);
	}

	function strukturorganisasi()
	{
		$data['provinsi'] 		= $this->db->get('provinces');
		$data['halaman']		= 'Struktur Perusahaan';
		$data['judul']			= 'Struktur Organisasi';
		

		$this->load->view('user/view_struktur', $data);
	}	

	function about()
	{
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';

		$this->load->view('user/view_tentangkami', $data);
	}

	function contact()
	{
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		

		$this->load->view('user/view_contact', $data);
	}

	function keranjang()
	{
		$data['header']		= 'user/view_header';
		$data['footer']		= 'user/view_footer';
		$data['menu']		= 'user/view_menu';
		$data['halaman']	= 'Keranjang Belanja';
		$data['judul']		= 'Keranjang Belanja';
		$data['id_user']	= $this->session->userdata('id');

		$this->load->view('user/view_keranjangBelanja', $data);
	}

	function daftar()
	{
		$data['provinsi'] 		= $this->db->get('provinces');
		$data['halaman']		= 'Daftar Akun BPR WMJ';
		$data['judul']			= 'Daftar Akun';

		$this->load->view('user/view_registrasiUser', $data);
	}

	function contact2()
	{
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		

		$this->load->view('user/view_contact', $data);
	}

	 function prosedur()
	{
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		$data['halaman']		= '';
		$data['judul']			= 'Prosedur Pengajuan';
		

		$this->load->view('user/view_prosedur', $data);
	}
	 function syarat_pengajuan()
	{
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		$data['halaman']		= '';
		$data['judul']			= 'Syarat Pengajuan';
		

		$this->load->view('user/view_syaratpengajuan', $data);
	}
 	function simulasikredit()
	{
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		$data['halaman'] = '';
		$data['judul']	 = 'Simulasi Perhitungan Kredit';

		$this->load->view('user/view_simulasikredit', $data);
	}
	function buku_tamu(){

      $nama_lengkap = $this->input->post('nama_lengkap');
      $email = $this->input->post('email');
      $pesan = $this->input->post('pesan');
      $this->form_validation->set_rules('nama_lengkap','Nama','required');
      $this->form_validation->set_rules('email','Elamat','required');
      $this->form_validation->set_rules('pesan','Pesan','required');
      
      if($this->form_validation->run() != false){
          $data = array(
            'nama_lengkap' => $nama_lengkap,
            'pesan' => $pesan,
            'email' => $email,
             
          );
          $this->m_user->insert_data($data,'buku_tamu');
          $this->session->set_flashdata('info','*Berhasil diposting');
     redirect(base_url('Home/contact'));
        }else{
          
         redirect(base_url('Home/contact'));
          $this->session->set_flashdata('info','*Gagal diposting');
        }
      }

	function getKota($key)
	{
		$city	= $this->Model_wilayah->getdata_kota($key);

		echo "<option value='0'>---PILIH KOTA---</option>";
		foreach($city->result() as $kota):
			echo "<option value=".$kota->id.">".$kota->name."</option>";
		endforeach;
 
	} 

	function simpan_registrasiUser()
	{
		$data['id_pemohon']  = $this->m_user->kode_otomatis_pemohon();
		$re_password						= md5($this->input->post('re-password'));
		$data['email']					= $this->input->post('email');
		$data['password']					= md5($this->input->post('password'));
		$data['username']				= $this->input->post('username');
		$data['no_telp'] 				= $this->input->post('no_telp');
		$data['nama_lengkap']				= $this->input->post('nama_lengkap');
		$data['id_provinces'] 			= $this->input->post('provinsi');
		$data['id_regencies']			= $this->input->post('kota');
		$data['alamat'] 				= $this->input->post('alamat');
		$data['kode_pos'] 				= $this->input->post('kode_pos');
		$data['aktif']					= 'NO';
		$data['tgl_daftar']				= date('Y-m-d');

		// memeriksa username (sudah terpakai atau belum) 
		$query = $this->db->get('pemohon');
		foreach($query->result() as $row)
		{
			if($row->username == $data['username'])
			{
				$this->session->set_flashdata('info','Username sudah terpakai');
				redirect(site_url('/home/daftar'));
			}
		}

		// cek password sama atau tidak
		if($re_password != $data['password'])			
		{
			// cek password baru sama atau tidak
			$this->session->set_flashdata('info','Password tidak sama');
				redirect(site_url('/home/daftar'));
		}
		// jika email diisi maka kirim pesan verifikasi email kepada user/customer
		// jika email tidak diisi pendaftaran selesai tanpa kirim email verifikasi
		else
		{
			$this->Model_user->getInsert($data);

			// kirim email ke user/nasabah
			$ci = get_instance();
	        $ci->load->library('email');
			$enkripsi 	 			= md5($data['tgl_daftar']);
	        $config['protocol'] 	= "smtp";
	        $config['smtp_host'] 	= "ssl://smtp.gmail.com";
	        $config['smtp_port'] 	= "465";
	        $config['smtp_user'] 	= "rohimahmuthmainnah03@gmail.com";
	        $config['smtp_pass'] 	= "980331ina";
	        $config['charset'] 		= "utf-8";
	        $config['mailtype'] 	= "html";
	        $config['newline'] 		= "\r\n";
	        
	        
	        $ci->email->initialize($config);
	 
	        $ci->email->from($config['smtp_user'], 'Admin BPR WMJ');
	        $ci->email->to($data['email']);
	        $ci->email->subject('Verifikasi Akun ');
	        $ci->email->message("terimakasih telah melakukan registrasi, untuk memverifikasi silahkan klik tautan dibawah ini<br><br>
	       						<a href=".site_url('/home/verifikasi/'.$enkripsi).">".site_url('/home/verifikasi/'.$enkripsi));
	        if ($this->email->send()) {
	            echo "Silahkan cek email Anda untuk melakukan verifikasi Akun <br>
	            	  Kembali ke halaman <a href=".site_url().">utama</a>";
	        } else {
	            show_error($this->email->print_debugger());
	        }
		} 
	}
 
	function verifikasi($key)
	{
		$this->Model_user->verifikasi($key);
		echo "Email Anda telah Aktif<br><br><a href='".site_url()."'>Kembali ke halaman utama</a>";
	}

	function cek_login()
	{
		$user 	= $this->input->post('username');
		$password	= md5($this->input->post('password'));

		$this->Model_user->cek_login($user,$password);
	} 
 
	function logout()
	{
		$this->session->sess_destroy();
		redirect(site_url());
	}

	   public function data_diri(){ 
    	$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		$data['halaman']		= '';
		$data['judul']			= 'Data Profil';

      $data['user'] = $this->m_user->edit_data(array('id_pemohon' => $this->session->userdata('id_pemohon')),'pemohon')->result();

      $d=$this->m_user->edit_data(array('pemohon.id_pemohon' => $this->session->userdata('id_pemohon')),'pemohon')->num_rows();

      $this->load->view('user/data_diri',$data);
     
    } 
    function cetak_bukti()
	{
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		$data['halaman']		= '';
		$data['judul']			= 'Cetak bukti pengajuan';
		

		$this->load->view('user/cetak_bukti', $data);
	}
     public function cetak_pendaftaran(){
			

				$data['aplikasi']=$this->m_user->edit_data4(array('pemohon.id_pemohon' => $this->session->userdata('id_pemohon')),'pemohon')->result();
			$d=$this->m_user->edit_data4(array('pemohon.id_pemohon' => $this->session->userdata('id_pemohon')),'pemohon')->num_rows();
 
			$this->load->view('user/cetak_pendaftaran',$data);

		} 

	public function status_pengajuan(){
			
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		$data['halaman']		= '';
		$data['judul']			= 'Status Pengajuan Kredit';
		$data['pengajuan']=$this->m_user->edit_data4(array('pemohon.id_pemohon' => $this->session->userdata('id_pemohon')),'pemohon')->result();
			$d=$this->m_user->edit_data4(array('pemohon.id_pemohon' => $this->session->userdata('id_pemohon')),'pemohon')->num_rows();
 
			$this->load->view('user/status_pengajuan',$data);

		}
	public function edit_profil($id){
			
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		$data['halaman']		= '';
		$data['judul']			= 'Edit Profil';
		$where = array('id_pemohon' =>$id);
        $data['pemohon'] = $this->db->query("select * from pemohon where id_pemohon='$id'")->result();


		$this->load->view('user/edit_profil',$data);

	}	

	function update_profil(){
      $id = $this->input->post('id');
      $nama_lengkap = $this->input->post('nama_lengkap');
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $alamat = $this->input->post('alamat');
      $no_telp = $this->input->post('no_telp');
      $email = $this->input->post('email');
      $foto = $this->input->post('foto');

      $this->form_validation->set_rules('nama_lengkap','Nama lengkap','required');
      $this->form_validation->set_rules('username','Username','required');
      $this->form_validation->set_rules('password','Password','required');
      $this->form_validation->set_rules('alamat','Alamat','required');
      $this->form_validation->set_rules('no_telp','No.Telepon','required');
      $this->form_validation->set_rules('email','email','required');

        if($this->form_validation->run() != false){

       $config['upload_path'] = 'assets/upload/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '2048';
        $config['file_name'] = 'gambar'.time();

        $this->load->library('upload',$config);

        if($this->upload->do_upload('foto')){
          $image = $this->upload->data();

            $where = array('id_pemohon' => $id);
            $data = array(
              'foto' => $image['file_name'],
              'nama_lengkap' => $nama_lengkap,
              'username' => $username,
              'password' => $password,
              'alamat' => $alamat,
              'no_telp' => $no_telp,
              'email' => $email,
            );

            $this->m_user->update_data('pemohon',$data,$where);
            redirect(base_url().'Home/data_diri');
          } else{
              $where = array('id_pemohon' =>$id);
              $data['pemohon'] = $this->db->query("select * from pemohon where id_pemohon='$id'")->result();
      
              redirect(base_url().'Home/edit_profil');
             
          }
      }
    }


 

}