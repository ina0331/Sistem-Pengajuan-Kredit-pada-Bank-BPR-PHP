<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin extends CI_Controller {
	function __construct(){
		parent::__construct();
		
		// cek login
	}
	public function index(){
 	if($this->session->userdata('id_admin') == ""){
			redirect(base_url('admin/login'));
		}else{
      
			$this->load->view('admin/dashboard');
			
  } 

  } 	  
 	  public function login(){
 	  	if($this->session->userdata('id_admin') != ""){
			redirect(base_url('admin'));
		}
 	  	$data['judul'] = "Login";   
 	  	$this->load->view('admin/login',$data); 
 	  	
 	  }

 	  public function login_proses(){
 	  	$username = $this->input->post('username');
 	  	$password = md5($this->input->post('password'));

 	  	// num_rows();jumlah isi data table
 	  	// row_array(); bongkar satuan data table
 	  	// result(); bongkar total table

 	  	$cek_login = $this->m_admin->login($username,$password)->num_rows();

 	  	

 	  	// echo $cek_login;

 	  	if ($cek_login==0){
        $this->session->set_flashdata('alert','Login Gagal! Username atau Password yang anda masukkan salah');
 	  		redirect(base_url('admin/login'));
 	  	}else{

 	  		$data_login = $this->m_admin->login($username,$password)->row_array();
 	  		$id_admin = $data_login['id_admin'];

 	  		$this->session->set_userdata('id_admin',$id_admin);
	 	  	$data_session = $this->m_admin->login($username,$password)->row_array();

	 	  	// $this->session->set_userdata($id_session);
	 	  	redirect('admin');
 	  	}
 	  	
 	  	}
 	function logout(){
 		$this->session->sess_destroy();
 		redirect(base_url('admin'));
 	}

 	function pemohon (){
    if($this->session->userdata('id_admin') == ""){
      redirect(base_url('admin/login'));
    }else{
 	   $data['pemohon'] = $this->m_admin->get_data('pemohon')->result();
 		$this->load->view('admin/view_pemohon',$data);
 	}
		 }
	function tambah_pemohon (){
 	  
 		$this->load->view('admin/tambah_pemohon');
 	}

 	 function tambah_data_pemohon_act(){
      $nama_lengkap = $this->input->post('nama_lengkap');
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $email = $this->input->post('email');
      $no_telp = $this->input->post('no_telp');
      $alamat = $this->input->post('alamat');
     
      $this->form_validation->set_rules('nama_lengkap','Nama','required');
      $this->form_validation->set_rules('username','Username','required');
      $this->form_validation->set_rules('password','Password','required');
      $this->form_validation->set_rules('email','Elamat','required');
      $this->form_validation->set_rules('no_telp','Nomor Telepon','required');
      if($this->form_validation->run() != false){
          $data = array(
          	'id_pemohon' => $this->m_user->kode_otomatis_pemohon(),
            'nama_lengkap' => $nama_lengkap,
            'username' => $username,
            'password' => $password,
            'email' => $email,
            'no_telp' => $no_telp,
            'alamat' => $alamat,
            'tgl_daftar'=> date('Y-m-d'),

          );
           $this->m_admin->insert_data($data,'pemohon');
          $this->session->set_flashdata("sukses", "<div class='alert alert-success'><strong>Simpan data BERHASIL dilakukan</strong></div>");
 
          redirect(base_url().'admin/pemohon');
        }else{
         $this->session->set_flashdata("alert", "<div class='alert alert-danger'><strong>Simpan data GAGAL di lakukan</strong></div>");
         redirect(base_url().'admin/tambah_pemohon');
          
        }
      }

       function edit_pemohon($id){
        if($this->session->userdata('id_admin') == ""){
      redirect(base_url('admin/login'));
    }else{
        $where = array('id_pemohon' =>$id);
        $data['pemohon'] = $this->db->query("select * from pemohon where id_pemohon='$id'")->result();


        $this->load->view('admin/edit_pemohon',$data);
        
      }
    }

      function update_pemohon(){
      $id = $this->input->post('id');
      $nama_lengkap = $this->input->post('nama_lengkap');
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $alamat = $this->input->post('alamat');
      $no_telp = $this->input->post('no_telp');
      $email = $this->input->post('email');

      $this->form_validation->set_rules('nama_lengkap','Nama lengkap','required');
      $this->form_validation->set_rules('username','Username','required');
      $this->form_validation->set_rules('password','Password','required');
      $this->form_validation->set_rules('alamat','Alamat','required');
      $this->form_validation->set_rules('no_telp','No.Telepon','required');
      $this->form_validation->set_rules('email','email','required');

        if($this->form_validation->run() != false){
            $where = array('id_pemohon' => $id);
            $data = array(
              'nama_lengkap' => $nama_lengkap,
              'username' => $username,
              'password' => $password,
              'alamat' => $alamat,
              'no_telp' => $no_telp,
              'email' => $email,
            );

            $this->m_admin->update_data('pemohon',$data,$where);
            redirect(base_url().'admin/pemohon');
          } else{
              $where = array('id_pemohon' =>$id);
              $data['pemohon'] = $this->db->query("select * from pemohon where id_pemohon='$id'")->result();
      
              $this->load->view('admin/edit_pemohon',$data);
             
          }
      }

     
      function hapus_pemohon($id){
        $where = array('id_pemohon' => $id);
        $this->m_admin->delete_data($where,'pemohon');
        $this->session->set_flashdata("sukses", "<div class='alert alert-success'><strong>Hapus data BERHASIL dilakukan</strong></div>");
        redirect(base_url().'admin/pemohon');
      }

      public function buku_tamu(){
        if($this->session->userdata('id_admin') == ""){
      redirect(base_url('admin/login'));
    }else{
    $data['buku_tamu'] = $this->m_admin->get_data('buku_tamu')->result();
    $this->load->view('admin/buku_tamu',$data);
  } 
 } 
  function hapus_bukutamu($id){
        $where = array('no_bukutamu' => $id);
        $this->m_admin->delete_data($where,'buku_tamu');
        $this->session->set_flashdata("sukses", "<div class='alert alert-success'><strong>Hapus data BERHASIL dilakukan</strong></div>");
        redirect(base_url().'admin/buku_tamu');
      }


       public function data_admin(){
        if($this->session->userdata('id_admin') == ""){
      redirect(base_url('admin/login'));
    }else{
 		$data['data_admin'] = $this->m_admin->get_data('admin')->result();
 		$this->load->view('admin/v_data_admin',$data);
 	} 
 }

 	  function tambah_data_admin(){
      if($this->session->userdata('id_admin') == ""){
      redirect(base_url('admin/login'));
    }else{
      $this->load->view('admin/v_tambah_data_admin');
    }
  }

    function tambah_data_admin_act(){ 
      $nama_lengkap = $this->input->post('nama_lengkap');
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $email = $this->input->post('email');
      $alamat = $this->input->post('alamat');
      $no_telp = $this->input->post('no_telp');
     
  
      	$config['upload_path'] = 'assets1/dist/img/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '2048';
        $config['file_name'] = 'gambar'.time();

        $this->load->library('upload',$config);

        if($this->upload->do_upload('fotoprofil')){
          $image = $this->upload->data();

          $data = array(
            'id_admin' => $this->m_admin->kode_otomatis_admin(),
            'fotoprofil' => $image['file_name'],
            'nama_lengkap' => $nama_lengkap,
            'username' => $username,
            'password' => $password,
            'email' => $email,
            'alamat' => $alamat,
            'no_telp' => $no_telp,
          );
           $this->m_admin->insert_data($data,'admin');
           $this->session->set_flashdata("sukses", "<div class='alert alert-success'><strong>Simpan data BERHASIL dilakukan</strong></div>");
 
          redirect(base_url().'admin/data_admin');
        }else{
           $this->session->set_flashdata("alert", "<div class='alert alert-danger'><strong>Simpan data GAGAL di lakukan</strong></div>");
          redirect(base_url().'admin/tambah_data_admin');
          
        } 
      }
  

  public function data_diri(){
    if($this->session->userdata('id_admin') == ""){
        redirect(base_url('admin/login'));
      }else{
      $data['admin'] = $this->m_admin->edit_data(array('id_admin' => $this->session->userdata('id_admin')),'admin')->result();

      $d=$this->m_admin->edit_data(array('admin.id_admin' => $this->session->userdata('id_admin')),'admin')->num_rows();
      $this->load->view('admin/data_diri',$data);
    }
  }  
     function edit_admin($id){
        $where = array('id_admin' =>$id);
        $data['admin'] = $this->db->query("select * from admin where id_admin='$id'")->result();


        $this->load->view('admin/edit_admin',$data);
        
      }

      function update_admin(){
      $id = $this->input->post('id');
      $nama_lengkap = $this->input->post('nama_lengkap');
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $alamat = $this->input->post('alamat');
      $no_telp = $this->input->post('no_telp');
      $email = $this->input->post('email');
      $fotoprofil = $this->input->post('fotoprofil');

      $this->form_validation->set_rules('nama_lengkap','Nama lengkap','required');
      $this->form_validation->set_rules('username','Username','required');
      $this->form_validation->set_rules('password','Password','required');
      $this->form_validation->set_rules('alamat','Alamat','required');
      $this->form_validation->set_rules('no_telp','No.Telepon','required');
      $this->form_validation->set_rules('email','email','required');

        if($this->form_validation->run() != false){

       $config['upload_path'] = 'assets1/dist/img/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '2048';
        $config['file_name'] = 'gambar'.time();

        $this->load->library('upload',$config);

        if($this->upload->do_upload('fotoprofil')){
          $image = $this->upload->data();

            $where = array('id_admin' => $id);
            $data = array(
              'fotoprofil' => $image['file_name'],
              'nama_lengkap' => $nama_lengkap,
              'username' => $username,
              'password' => $password,
              'alamat' => $alamat,
              'no_telp' => $no_telp,
              'email' => $email,
            );

            $this->m_admin->update_data('admin',$data,$where);
            redirect(base_url().'admin/data_diri');
          } else{
              $where = array('id_admin' =>$id);
              $data['admin'] = $this->db->query("select * from admin where id_admin='$id'")->result();
      
              $this->load->view('admin/edit_admin',$data);
             
          }
      }
    }

    function berkas (){
      if($this->session->userdata('id_admin') == ""){
      redirect(base_url('admin/login'));
    }else{
    $data['berkas'] = $this->m_admin->get_data('berkas')->result();
    $this->load->view('admin/view_berkas',$data);
  }
}
   function hapus_berkas($id){
        $where = array('id_pemohon' => $id);
        $this->m_admin->delete_data($where,'berkas');
        $this->session->set_flashdata("sukses", "<div class='alert alert-success'><strong>Hapus data BERHASIL dilakukan</strong></div>");
        redirect(base_url().'admin/berkas');
      }

   function hapus_pengajuan($id){
        $where = array('id_aplikasi' => $id);
        $this->m_admin->delete_data($where,'aplikasi');
        $this->session->set_flashdata("sukses", "<div class='alert alert-success'><strong>Hapus data BERHASIL dilakukan</strong></div>");
        redirect(base_url().'admin/pengajuan');
      }
     
   function pengajuan (){
    if($this->session->userdata('id_admin') == ""){
      redirect(base_url('admin/login'));
    }else{
    $data['pengajuan'] = $this->m_admin->get_data('aplikasi')->result();
    $this->load->view('admin/view_pengajuan',$data);
  }
}

     function lihat_pengajuan($id){
        $where = array('id_aplikasi' =>$id);
        $data['pengajuan'] = $this->db->query("select * from aplikasi where id_aplikasi='$id'")->result();


        $this->load->view('admin/lihat_pengajuan',$data);
        
      }

      function edit_status($id){
        $where = array('id_aplikasi' =>$id);
        $data['data_status'] = $this->db->query("select * from aplikasi where id_aplikasi='$id'")->result();

        $this->load->view('admin/edit_status',$data);
      
      }

  function update_status(){
      $id = $this->input->post('id');
      $nama_lengkap = $this->input->post('nama_lengkap');
    
     
      $status = $this->input->post('status');


     
   
     
      $this->form_validation->set_rules('status','Status','required');

        if($this->form_validation->run() != false){
            $where = array('id_aplikasi' => $id);
            $data = array(
              'nama_lengkap' => $nama_lengkap,
            
            
              'status' => $status,
            );

            $this->m_admin->update_data('aplikasi',$data,$where);
            redirect(base_url().'admin/pengajuan');
          } else{
              $where = array('id_aplikasi' =>$id);
              $data['data_status'] = $this->db->query("select * from aplikasi where id_aplikasi='$id'")->result();
            
              $this->load->view('admin/edit_status',$data);
         
          }
      }


    
     function laporan_print_pengajuan(){
         $dari = $this->input->get('dari');
          $sampai = $this->input->get('sampai');

          if($dari != "" && $sampai != ""){
          $data['laporan'] = $this->db->query("select * from aplikasi p,berkas d, 
          pemohon a where p.id_pemohon=a.id_pemohon and d.id_pemohon=a.id_pemohon
          and date(tgl_beli) >= '$dari'")->result();
            $this->load->view('admin/laporan_print_pengajuan',$data);
          }else{
            redirect("admin/cetak_pengajuan"); 
          }
        }

     function laporan_print_pemohon(){
          $data['pemohon'] = $this->m_admin->get_data('pemohon')->result();
          $this->load->view('admin/laporan_print_pemohon',$data);
        }


    function cetak_laporan(){
      if($this->session->userdata('id_admin') == ""){
      redirect(base_url('admin/login'));
    }else{

    $this->load->view('admin/cetak_laporan');
  }  
} 

  function cetak_pengajuan(){

          $dari = $this->input->post('dari');
          $sampai = $this->input->post('sampai');
          $this->form_validation->set_rules('dari','Dari Tanggal','required');
          $this->form_validation->set_rules('sampai','Sampai Tanggal','required');

          if($this->form_validation->run() != false){

          $data['laporan'] = $this->db->query("select * from aplikasi p,berkas d, 
          pemohon a where p.id_pemohon=a.id_pemohon and d.id_pemohon=a.id_pemohon
          and date(tgl_beli) >= '$dari'")->result();

         
          $this->load->view('admin/laporan_filter_pengajuan',$data);
         
        }else{
         
          $this->load->view('admin/laporan_transaksi');
         
        }
        }  

    function pesan (){
   
    $data['pemohon'] = $this->m_admin->get_data('pemohon')->result();
    $this->load->view('admin/edit_pesan',$data); 
  }

    function lihat_pesan (){
      if($this->session->userdata('id_admin') == ""){
      redirect(base_url('admin/login'));
    }else{
     $data['pesan'] = $this->m_admin->get_data('pesan')->result();
    $this->load->view('admin/view_pesan',$data);
  }
}

      function kirim_pesan()
      {
        if($this->session->userdata('id_admin') == ""){
        redirect(base_url('admin/login'));
      }else{
   $data['id_admin'] =       $this->session->userdata('id_admin');
    $data['email']          = $this->input->post('email');
    $data['id_pemohon']      = $this->input->post('id_pemohon');
    $data['subjek']          = $this->input->post('subjek');
    $data['tgl_kirim']       = date('Y-m-d');
    $data['status_kirim']       = 'Telah Dikirim';

    $this->m_admin->simpan_data($data);


          $ci = get_instance();
          $ci->load->library('email');
          $enkripsi         = md5($data['tgl_kirim']);
          $config['protocol']   = "smtp";
          $config['smtp_host']  = "ssl://smtp.gmail.com";
          $config['smtp_port']  = "465";
          $config['smtp_user']  = "rohimahmuthmainnah03@gmail.com";
          $config['smtp_pass']  = "980331ina";
          $config['charset']    = "utf-8";
          $config['mailtype']   = "html";
          $config['newline']    = "\r\n";
          
           
          $ci->email->initialize($config);
   
          $ci->email->from($config['smtp_user'], 'Admin BPR WMJ');
          $ci->email->to($data['email']);
          $ci->email->subject('Pencairan Dana');
          $ci->email->message($data['subjek']);
          if ($this->email->send()) {
              echo "Email Telah terkirim <a href=".site_url('admin/pesan').">utama</a>";
          } else {
              show_error($this->email->print_debugger());
          }


    }
     
  }
}