<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	function index()
	{
		
	}

	function aplikasi()
	{
		if($this->session->userdata('id_pemohon') == ""){
        redirect(base_url('home/login'));
      }else{
		$data['halaman']		= 'Aplikasi Pengajuan Kredit';
		$data['judul']			= 'Formulir Pengajuan';
		$id_pemohon = $this->session->userdata('id_pemohon');
 
		if(isset($id_pemohon))
		{
			$query					= $this->Model_user->getUser($id_pemohon);
			$data['id_pemohon']		= $id_pemohon;
			$data['berat']			= $this->cart->total_items();
			$data['nama_lengkap']	= $query->nama_lengkap;
			
			$data['alamat']			= $query->alamat;
			$data['no_telp']		= $query->no_telp;
			$data['kode_pos']		= $query->kode_pos;
			$data['kota1']			= $query->id_regencies;
			$data['provinsi1']		= $query->id_provinces;
			$data['provinsi'] 		= $this->db->get('provinces');
			$data['kota']	 		= $this->db->get('regencies');
			$data['status']			= 'Tertunda';
			$data['link']			= '<h1>Alamat Anda</h1>';
		} 
		else
		{
			$data['id_pemohon']		= '';
			
			$data['nama_lengkap']		= '';
		
			$data['alamat']			= '';
			$data['no_telp']		= '';
			$data['kode_pos']		= '';
			$data['provinsi'] 		= $this->db->get('provinces');
			$data['kota']	 		= $this->db->get('regencies');
			$data['kota1']			= '';
			$data['provinsi1']		= '';
			$data['status']			= 'Tertunda';
			$data['link']			= '<h1>Alamat Anda</h1>';
		}
        
		$this->load->view('user/view_aplikasi', $data);
	}
}

	function ambil_kota()
	{
		$curl = curl_init();
		 
		curl_setopt_array($curl, array(
		 CURLOPT_URL => "http://rajaongkir.com/api/starter/city",
		 CURLOPT_RETURNTRANSFER => true,
		 CURLOPT_ENCODING => "",
		 CURLOPT_MAXREDIRS => 10,
		 CURLOPT_TIMEOUT => 30,
		 CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		 CURLOPT_CUSTOMREQUEST => "GET",
		 CURLOPT_HTTPHEADER => array(
		 "key: 2f50e6a7c051609f97d7bf9174188064"
		 ),
		));
		 
		$response = curl_exec($curl);
		$err = curl_error($curl);
		 
		curl_close($curl);
		 
		if ($err) {
		 echo "cURL Error #:" . $err;
		} else {
		 
		 $k = json_decode($response, true);
		 echo json_encode($k['rajaongkir']['results']);
		 
		}
	}

	function result_ongkir($origin,$destination,$courier,$key='cek_ongkir',$weight)
	{
		$curl = curl_init();

		curl_setopt_array($curl, array(
		 CURLOPT_URL => "http://rajaongkir.com/api/starter/cost",
		 CURLOPT_RETURNTRANSFER => true,
		 CURLOPT_ENCODING => "",
		 CURLOPT_MAXREDIRS => 10,
		 CURLOPT_TIMEOUT => 30,
		 CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		 CURLOPT_POSTFIELDS => "origin=$origin&destination=$destination&weight=$weight&courier=$courier",
		 CURLOPT_HTTPHEADER => array(
		 "key: 2f50e6a7c051609f97d7bf9174188064"
		 ),
		));
		 
		$response = curl_exec($curl);
		$err = curl_error($curl);
		 
		curl_close($curl);
		 
		if ($err) {
		 echo "cURL Error #:" . $err;
		} else {
		 
		 $hasil['data'] 	= json_decode($response, true);
		 $hasil['weight']	= $weight/1000;
		}

		if($key == 'cek_ongkir')
		{
			$this->load->view('user/view_hasilOngkir',$hasil);	
		}
		else
		{
			$this->load->view('user/view_resultOngkir',$hasil);
		}
	} 

	public function simpan_formulir()
	{ 
		$data['id_aplikasi']  = $this->m_user->kode_otomatis();

	    $data['id_pemohon'] =       $this->session->userdata('id_pemohon');
		$data['nama_lengkap']	= $this->input->post('nama_lengkap');
		$data['alamat']			= $this->input->post('alamat');
		$data['kode_pos']		= $this->input->post('kode-pos');
		$data['id_province']	= $this->input->post('id_provinces');
		$data['id_regencies']	= $this->input->post('id_regencies');
		$data['telp']			= $this->input->post('telp');
		$data['jenis_kelamin']	= $this->input->post('jenis_kelamin');
		$data['tgl_lahir']		= $this->input->post('tgl_lahir');
		$data['tempat_lahir']	= $this->input->post('tempat_lahir');
		$data['agama']			= $this->input->post('agama');
		$data['pendidikan']		= $this->input->post('pendidikan');
		$data['status_perkawinan']		= $this->input->post('status_perkawinan');
		$data['jml_tanggungan']			= $this->input->post('jml_tanggungan');
		$data['nama_pasangan']			= $this->input->post('nama_pasangan');
		$data['ibu_kandung']			= $this->input->post('ibu_kandung');
		$data['pihak_dihubungi']		= $this->input->post('pihak_dihubungi');
		$data['hub_kel']			= $this->input->post('hub_kel');
		$data['alamat_kel']			= $this->input->post('alamat_kel');	
		$data['telp_kel']			= $this->input->post('telp_kel');
		$data['nama_perusahaan']	= $this->input->post('nama_perusahaan');
		$data['alamat_per']			= $this->input->post('alamat_per');
		$data['jenis_pekerjaan']	= $this->input->post('jenis_pekerjaan');
		$data['lama_bekerja']		= $this->input->post('lama_bekerja');
		$data['tipe_pendapatan']	= $this->input->post('tipe_pendapatan');
		$data['pendapatan']			= $this->input->post('pendapatan');
		$data['SIUP']			= $this->input->post('SIUP');
		$data['NPWP_per']			= $this->input->post('NPWP_per');
		$data['jumlah_kredit']		= $this->input->post('jumlah_kredit');
		$data['jangka_waktu']		= $this->input->post('jangka_waktu');
		$data['tujuan_kredit']		= $this->input->post('tujuan_kredit');
		$data['status']			= 'TERTUNDA';
		$data['tgl_beli']		= date('Y-m-d');


		

			$this->Model_formulir->simpan_formulir($data);
			redirect(site_url('/user/upload_berkas'));
		}

		// //BELUM SELESAI MOHON DISELESAIKAN (kurang menampilkan produk keseluruhan)

		// //ambil id_admin dan ambil email marketing
		// $id_admin = $this->model_customer->getdata($key);
		// $email 	  = $this->model_order->getdata_email($id_admin->id_admin);

		// //kirim email pesanan ke admin dan marketing
		// $ci = get_instance();
  //       $ci->load->library('email');
  //       $config['protocol'] 	= "smtp";
  //       $config['smtp_host'] 	= "ssl://smtp.gmail.com";
  //       $config['smtp_port'] 	= "465";
  //       $config['smtp_user'] 	= "toptrackerstore79@gmail.com";
  //       $config['smtp_pass'] 	= "Bukitbarisan79";
  //       $config['charset'] 		= "utf-8";
  //       $config['mailtype'] 	= "html";
  //       $config['newline'] 		= "\r\n";
        
        
  //       $ci->email->initialize($config);
        
 	// 	//BELUM SELESAI
  //   	$this->email->clear();
  //       $this->email->from($config['smtp_user'], 'Top Tracker Store');
  //       $this->email->to($email->email);
  //       $this->email->subject('Pesanan Baru');
  //   	$this->email->message("<h2>Pesanan Baru</h2>
  //  						<br><br>Nama Toko&nbsp:&nbsp;".strtoupper($query->nama_toko).
		// 	 			"<br>Tanggal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;".generate_tanggal(gmdate('d/m/Y-H:i',$data['tgl_beli'])));
  //       if ($this->email->send() == FALSE) {
  //           show_error($this->email->print_debugger());
  //       } 

function upload_berkas()
	{
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		$data['halaman']		= 'Aplikasi Pengajuan Kredit';
		$data['judul']			= 'Upload Berkas';

		$data['aplikasi']=$this->m_user->edit_data4(array('pemohon.id_pemohon' => $this->session->userdata('id_pemohon')),'pemohon')->result();
      $d=$this->m_user->edit_data4(array('pemohon.id_pemohon' => $this->session->userdata('id_pemohon')),'pemohon')->num_rows();
		

		$this->load->view('user/view_uploadberkas', $data);
	}

function upload_berkas_jaminan()
	{
		$data['header']	= 'user/view_header';
		$data['footer']	= 'user/view_footer';
		$data['menu']	= 'user/view_menu';
		$data['halaman']		= 'Aplikasi Pengajuan Kredit';
		$data['judul']			= 'Upload Berkas';
		

		$this->load->view('user/view_berkas_agunan', $data);
	}

function upload_berkas_jaminan_act()
	{
		if($this->session->userdata('id_pemohon') == ""){
        redirect(base_url('home/login'));
      }else{

       $config['upload_path'] = './assets/images/berkas/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '2048';
        $config['file_name'] = 'berkas'.time();

        $this->load->library('upload',$config);

        if($this->upload->do_upload('sertifikat')){
          $image = $this->upload->data();

        if($this->upload->do_upload('pbb')){
          $image2 = $this->upload->data();

       $data = array(
          	'id_pemohon' => $this->session->userdata('id_pemohon'),
            'sertifikat' => $image['file_name'],
            'pbb' => $image2['file_name'],
             );
      
          $this->m_user->insert_data($data,'berkas');
          $this->session->set_flashdata('info','*Berhasil diupload');
     redirect(site_url());
        }else{
 redirect(site_url('/user/upload_berkas_jaminan'));
           $this->session->set_flashdata('info','*Tidak dapat diupload');
		
 }
 }
 }
 }     


function upload_berkas_act()
	{
		if($this->session->userdata('id_pemohon') == ""){
        redirect(base_url('home/login'));
      }else{

        $id_aplikasi = $this->input->post('id_aplikasi');
        $jaminan = $this->input->post('jaminan');

        $config['upload_path'] = './assets/images/berkas/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '2048';
        $config['file_name'] = 'berkas'.time();

        $this->load->library('upload',$config);

        if($this->upload->do_upload('ktp')){
          $image = $this->upload->data();

        if($this->upload->do_upload('kk')){
          $image2 = $this->upload->data();

        if($this->upload->do_upload('pasfoto')){
          $image3 = $this->upload->data();

        if($this->upload->do_upload('npwp')){
          $image4 = $this->upload->data();

        if($this->upload->do_upload('rekening_listrik')){
          $image5 = $this->upload->data();

        if($this->upload->do_upload('struk_gaji')){
          $image6 = $this->upload->data();

        if($this->upload->do_upload('berkas_agunan')){
          $image7 = $this->upload->data();

          $data = array(
          	'kd_berkas' => $this->m_user->kode_otomatis_berkas(),
          	'id_pemohon' => $this->session->userdata('id_pemohon'),
          	'id_aplikasi' => $id_aplikasi,
            'ktp' => $image['file_name'],
            'kk' => $image2['file_name'],
            'pasfoto' => $image3['file_name'],
            'npwp' => $image4['file_name'],
            'rekening_listrik' => $image5['file_name'],
            'struk_gaji' => $image6['file_name'],
            'jaminan' => $jaminan,
            'berkas_agunan' => $image7['file_name'],

             );
      
          $this->m_user->insert_data($data,'berkas');
          $this->session->set_flashdata('info','*Berhasil diupload');
     redirect(site_url('/home/cetak_bukti'));
        }else{
 redirect(site_url('/user/upload_berkas'));
           $this->session->set_flashdata('info','*Tidak dapat diupload');
		
	}
	}
	} 
}
}
}
}
}
}
}

 

/* End of file User.php */
/* Location: ./application/controllers/User.php */