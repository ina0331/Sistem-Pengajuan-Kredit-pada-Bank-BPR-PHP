 <!DOCTYPE html>
<html>
  <head>
    <?php $this->load->view('admin/head'); ?>
    <link href="<?php echo base_url(); ?>assets1/dist/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />

  </head>
  <body class="skin-blue">
  <!-- wrapper di bawah footer -->
    <div class="wrapper">
      
      <?php $this->load->view('admin/head2'); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php $this->load->view('admin/sidebar'); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <b>DATA PENGAJUAN KREDIT</b>
          </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

          <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-md-12">
              
              <div class="box">
                <span id="pesan-flash"><?php echo $this->session->flashdata('sukses'); ?></span>
                <span id="pesan-error-flash"><?php echo $this->session->flashdata('alert'); ?></span>
                <div class="box-title">
                  
                </div><!-- /.box-title -->
                <div class="box-body">
                 <table id="example1" class="table table-bordered table-striped">

   <?php 
  
    foreach ($pengajuan as $a) {
  ?>
              <tr><th><h4>IDENTITAS PRIBADI</h4></th><th>:</th></th></tr>
              <tr><th>ID APLIKASI</th><th>:</th><th><?php echo $a->id_aplikasi ?></th></tr>
              <tr><th>ID PEMOHON</th><th>:</th><th><?php echo $a->id_pemohon ?></th></tr>
              <tr><th>NAMA PEMOHON</th><th>:</th><th><?php echo $a->nama_lengkap ?></th></tr>
              <tr><th>JENIS KELAMIN</th><th>:</th><th><?php echo $a->jenis_kelamin ?></th></tr>
              <tr><th>TEMPAT LAHIR</th><th>:</th><th><?php echo $a->tempat_lahir ?></th></tr>
              <tr><th>TGL LAHIR</th><th>:</th><th><?php echo $a->tgl_lahir ?></th></tr>
              <tr><th>AGAMA</th><th>:</th><th><?php echo $a->agama ?></th></tr>
              <tr><th>ALAMAT</th><th>:</th><th><?php echo $a->alamat ?></th></tr>
              <tr><th>KODE POS</th><th>:</th><th><?php echo $a->kode_pos ?></th></tr>
              <tr><th>NO.TELEPON</th><th>:</th><th><?php echo $a->telp ?></th></tr>
              <tr><th>PENDIDIKAN TERAKHIR</th><th>:</th><th><?php echo $a->pendidikan ?></th></tr>
              <tr><th>TGL PENGAJUAN</th><th>:</th><th><?php echo $a->tgl_beli ?></th></tr>
              <tr><th>STATUS PERKAWINAN</th><th>:</th><th><?php echo $a->status_perkawinan ?></th></tr>
              <tr><th>NAMA PASANGAN</th><th>:</th><th><?php echo $a->nama_pasangan ?></th></tr>
              <tr><th>JUMLAH TANGGUNGAN</th><th>:</th><th><?php echo $a->jml_tanggungan ?></th></tr>
              <tr><th>IBU KANDUNG</th><th>:</th><th><?php echo $a->ibu_kandung ?></th></tr>
              <tr><th>PIHAK YANG DAPAT DIHUBUNGI</th><th>:</th><th><?php echo $a->pihak_dihubungi ?></th></tr>
              <tr><th>HUBUNGAN DENGAN PEMOHON</th><th>:</th><th><?php echo $a->hub_kel ?></th></tr>
              <tr><th>ALAMAT PIHAK YG DIHUBUNGI</th><th>:</th><th><?php echo $a->alamat_kel ?></th></tr>
              <tr><th>NO.TLP PIHAK YG DIHUBUNGI</th><th>:</th><th><?php echo $a->telp_kel ?></th></tr>
              <tr><th></th></tr>
              <tr><th><h4>DATA PERUSAHAAN/USAHA</h4></th><th>:</th></th></tr>
              <tr><th>TIPE PENDAPATAN</th><th>:</th><th><?php echo $a->tipe_pendapatan ?></th></tr>
              <tr><th>JENIS PEKERJAAN</th><th>:</th><th><?php echo $a->jenis_pekerjaan ?></th></tr>
              <tr><th>NAMA PERUSAHAAN</th><th>:</th><th><?php echo $a->nama_perusahaan ?></th></tr>
              <tr><th>ALAMAT PERUSAHAAN</th><th>:</th><th><?php echo $a->alamat_per ?></th></tr>
              <tr><th>LAMA BEKERJA</th><th>:</th><th><?php echo $a->lama_bekerja ?></th></tr>
              <tr><th>PENDAPATAN</th><th>:</th><th><?php echo $a->pendapatan ?></th></tr>
              <tr><th>NO. SIUP USAHA</th><th>:</th><th><?php echo $a->SIUP ?></th></tr>
              <tr><th>NPWP USAHA</th><th>:</th><th><?php echo $a->NPWP_per ?></th></tr>
              <tr><th></th></tr>
              <tr><th><h4>DATA PENGAJUAN KREDIT</h4></th><th>:</th></th></tr>
              <tr><th>JUMLAH KREDIT</th><th>:</th><th><?php echo $a->jumlah_kredit ?></th></tr>
              <tr><th>JANGKA WAKTU</th><th>:</th><th><?php echo $a->jangka_waktu ?></th></tr>
              <tr><th>TUJUAN KREDIT</th><th>:</th><th><?php echo $a->tujuan_kredit ?></th></tr>
              <tr><th>STATUS</th><th>:</th><th><?php echo $a->status ?></th></tr>
              <tr><th><a href="#" class="btn btn-sm btn-info btn-block btn-flat" onclick="window.history.go(-1)"><b>Kembali</b></a></th></tr>
                      
                    
                    <?php } ?>
                  </tbody>
                </table> 
              </div>
            </div><!-- /.box -->
          </div><!-- /.col -->
       


          <!-- right col (We are only adding the ID to make the widgets sortable)-->
          <section class="col-lg-5 connectedSortable">

          </section><!-- right col -->
        </div><!-- /.row (main row) -->

      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
    <footer class="main-footer">
      <div class="pull-right hidden-xs">
        <!-- <b>Version</b> 2.0 -->
      </div>
      <strong>Copyright &copy; 2020 <a href="#"></a></strong>
    </footer>
  </div><!-- ./wrapper -->
  <!-- page script -->
  

    
    <?php $this->load->view('admin/footer'); ?>
    <script src="<?php echo base_url(); ?>assets1/dist/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets1/dist/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <script type="text/javascript">
      $(function() {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": true,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false


        });
      });
            //waktu flash data :v
      $(function(){
      $('#pesan-flash').delay(4000).fadeOut();
      $('#pesan-error-flash').delay(5000).fadeOut();
      });
    </script>
</body>
</html>