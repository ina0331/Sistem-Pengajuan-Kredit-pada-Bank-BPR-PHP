 <!DOCTYPE html>
<html>
  <head>
    <?php $this->load->view('admin/head'); ?>
    <link href="<?php echo base_url(); ?>assets1/dist/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />

  </head>
  <body class="skin-blue">
  <!-- wrapper di bawah footer -->
    <div class="wrapper">
      
      <?php $this->load->view('admin/head2'); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php $this->load->view('admin/sidebar'); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <b>DATA DAFTAR ADMIN</b>
          </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

          <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-md-12">
              <a style="margin-bottom:3px" href="<?php echo base_url().'admin/tambah_data_admin'; ?>" class="btn btn-primary no-radius dropdown-toggle"><span class="glyphicon glyphicon-plus"></span> TAMBAH DATA ADMIN</a>

              <div class="box">
                <span id="pesan-flash"><?php echo $this->session->flashdata('sukses'); ?></span>
                <span id="pesan-error-flash"><?php echo $this->session->flashdata('alert'); ?></span>
                <div class="box-title">
                  
                </div><!-- /.box-title -->
                <div class="box-body">
                 <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>NO</th>
                      <th>ID ADMIN</th>
                      <th>NAMA ADMIN</th>
                      <th>USERNAME</th>
                      <th>EMAIL</th>
                      <th>ALAMAT</th>
                      <th>NO.TELEPON</th>
                      <th>FOTO PROFIL</th>
                    </tr>
                  </thead>
                  <tbody>
                   
      <?php
      $no = 1;
      foreach ($data_admin as $a) {
      ?>
                    <tr>
                      <td><?php echo $no++; ?></td>
                      <td><?php echo $a->id_admin ?></td>
                      <td><?php echo $a->nama_lengkap ?></td>
                      <td><?php echo $a->username ?></td>
                      <td><?php echo $a->email ?></td>
                      <td><?php echo $a->alamat ?></td>
                      <td><?php echo $a->no_telp ?></td>
                      <td><img src="<?php echo base_url();?>assets1/dist/img/<?=$a->fotoprofil;?>" style="max-width:100%; max-height: 100%; height: 120px; width: 120px"></td>
                      
                     
                    </tr>
                    <?php } ?>
                  </tbody>
                </table> 
              </div>
            </div><!-- /.box -->
          </div><!-- /.col -->
       


          <!-- right col (We are only adding the ID to make the widgets sortable)-->
          <section class="col-lg-5 connectedSortable">

          </section><!-- right col -->
        </div><!-- /.row (main row) -->

      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
    <footer class="main-footer">
      <div class="pull-right hidden-xs">
        <!-- <b>Version</b> 2.0 -->
      </div>
      <strong>Copyright &copy; 2020 <a href="#"></a></strong>
    </footer>
  </div><!-- ./wrapper -->
  <!-- page script -->
  

    
    <?php $this->load->view('admin/footer'); ?>
    <script src="<?php echo base_url(); ?>assets1/dist/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets1/dist/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <script type="text/javascript">
      $(function() {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": true,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false


        });
      });
            //waktu flash data :v
      $(function(){
      $('#pesan-flash').delay(4000).fadeOut();
      $('#pesan-error-flash').delay(5000).fadeOut();
      });
    </script>
</body>
</html>