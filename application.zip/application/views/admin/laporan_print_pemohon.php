<!DOCTYPE html>
<html>
<head>
 <title></title>
</head>
<body>
 <style type="text/css">
 .table-data{
   width: 100%;
   border-collapse: collapse;
  }

  .table-data tr th,
  .table-data tr td{
   border:1px solid black;
   font-size: 10pt;
  }
 </style> 

 <h3 align="center">Laporan Data Pengajuan Surat</h3>
 <br/>
 <table class="table-data">
  <thead>
  	 <tr>
                      <th>NO</th>
                      <th>ID PEMOHON</th>
                      <th>NAMA PEMOHON</th>
                      <th>USERNAME</th>
                      <th>EMAIL</th>
                      <th>ALAMAT</th>
                      <th>NO.TELEPON</th>
                      <th>TGL DAFTAR</th>
                      <th>AKTIF</th>
               
                    </tr>
                  </thead>
                  <tbody>
                   
      <?php
      $no = 1;
      foreach ($pemohon as $a) {
      ?>
                    <tr>
                      <td><?php echo $no++; ?></td>
                      <td><?php echo $a->id_pemohon ?></td>
                      <td><?php echo $a->nama_lengkap ?></td>
                      <td><?php echo $a->username ?></td>
                      <td><?php echo $a->email ?></td>
                      <td><?php echo $a->alamat ?></td>
                      <td><?php echo $a->no_telp ?></td>
                      <td><?php echo $a->tgl_daftar ?></td>
                      <td> <?php echo $a->aktif ?></td>

      </tr>
   <?php
  }
  ?>



<script type="text/javascript">
 window.print();
</script>

</body>
</html>
