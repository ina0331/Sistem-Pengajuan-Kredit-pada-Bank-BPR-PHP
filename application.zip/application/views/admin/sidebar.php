<section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">

             
            </div>
            <div class="pull-left info">
              <p><?php if($id_admin = $this->session->userdata('id_admin')) { ?>
            <?php $data_user = $this->m_admin->get_data2('admin',$id_admin)->row_array(); echo $data_user['nama_lengkap'];?> 
          
                  <?php } ?> </p>
 
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MENU</li>
            <li>
              <a href="<?php echo base_url(); ?>admin">
                <i class="fa fa-home"></i> <span>Dashboard</span>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>admin/pengajuan">
                <i class="fa fa-tag"></i> <span>Data Pengajuan</span> 
              </a>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>admin/berkas">
                <i class="fa fa-folder"></i> <span>Data Berkas</span>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>admin/pemohon">
                <i class="fa fa-user"></i> <span>Data Pemohon
              </a>
            </li>
             <li>
              <a href="<?php echo base_url(); ?>admin/data_admin">
                <i class="fa fa-user"></i> <span>Data Admin
              </a>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>admin/buku_tamu">
                <i class="fa fa-book"></i> <span>Buku Tamu
              </a>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>admin/lihat_pesan">
                <i class="fa fa-tag"></i> <span>Kirim Pesan
              </a>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>admin/logout">
                <i class="fa fa-sign-out"></i> <span>Logout</span> 
              </a>
            </li>
            
            <li class="header">Ini merupakan halaman pengelola web wmj cabang cibarusah</li>
            <!-- <li><a href="#"><i class="fa fa-circle-o text-danger"></i> Important</a></li>
            <li><a href="#"><i class="fa fa-circle-o text-warning"></i> Warning</a></li>
            <li><a href="#"><i class="fa fa-circle-o text-info"></i> Information</a></li> -->
          </ul>
        </section>