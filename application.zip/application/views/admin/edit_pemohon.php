<!DOCTYPE html>
<html>
<head>
  <link href="<?php echo base_url(); ?>assets1/dist/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
  <?php $this->load->view('admin/head'); ?>
  
</head>
<body class="skin-blue">
  <!-- wrapper di bawah footer -->
  <div class="wrapper">

    <?php $this->load->view('admin/head2'); ?>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
      <?php $this->load->view('admin/sidebar'); ?>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          <b>EDIT DATA PEMOHON</b>
        </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

        <!-- Main content -->
        <section class="content">
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-12">
            <!-- Chat box -->
            <div class="box">
              <div class="box-header">
                <i class="fa fa-plus"></i>
                <h3 class="box-title">FORM EDIT PEMOHON</h3>
              </div>
              <div class="box-body chat" id="chat-box">
<!-- /. NAV SIDE  -->
       <div class="item">
<?php foreach ($pemohon as $a){ ?>
<form action="<?php echo base_url().'admin/update_pemohon' ?>" method="post" enctype="multipart/form-data">

<div class="form-group">
    <label>Id user</label>
    <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
    <input type="id" name="id_pemohon" class="form-control" value="<?php echo $a->id_pemohon; ?>">
    <?php echo form_error('id_pemohon'); ?>
  </div>

  <div class="form-group">
      <label>Nama Pemohon</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="text" name="nama_lengkap" class="form-control" value="<?php echo $a->nama_lengkap; ?>">
      <?php echo form_error('nama_lengkap'); ?>
    </div>


    <div class="form-group">
      <label>username</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="md5" name="username" class="form-control" value="<?php echo $a->username; ?>">
      <?php echo form_error('username'); ?>
    </div>

     <div class="form-group">
      <label>password</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="password" name="password" class="form-control" value="<?php echo $a->password; ?>">
      <?php echo form_error('password'); ?>
    </div>

<div class="form-group">
      <label>No.telepon</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="number" name="no_telp" class="form-control" value="<?php echo $a->no_telp; ?>">
      <?php echo form_error('no_telp'); ?>
    </div>

 <div class="form-group">
      <label>Email</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="id" name="email" class="form-control" value="<?php echo $a->email; ?>">
      <?php echo form_error('email'); ?>
    </div>

  <div class="form-group">
      <label>Alamat</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <textarea style="height:100px" name="alamat" class="form-control" value="<?php echo $a->alamat; ?>"></textarea>
      <?php echo form_error('alamat'); ?>
    </div>

 
  <div class="form-group">
    <input type="submit" value="Update" class="btn btn-primary btn-block btn-flat">
    <input type="button" value="Kembali" class="btn btn-warning btn-block btn-flat" onclick="window.history.go(-1)">
  </div>
  </form>

                                                          <div>
                                                        </div>
                                                    </div>
                                                </div>
                                  
  <?php } ?>

  </section>
<section class="col-lg-5 connectedSortable">

          </section><!-- right col -->
        </div><!-- /.row (main row) -->

      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
    <footer class="main-footer">
      <div class="pull-right hidden-xs">
        <!-- <b>Version</b> 2.0 -->
      </div>
      <strong>Copyright &copy; 2020 <a href="#"></a></strong>
    </footer>
  </div><!-- ./wrapper -->
  <!-- page script -->
  

    
    <?php $this->load->view('admin/footer'); ?>
</body>
</html>

