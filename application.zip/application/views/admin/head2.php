<header class="main-header">
        <!-- Logo -->
        <a href="" class="logo"><b>Admin</b>BPR WMJ</a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
              <a href="<?php echo base_url(); ?>admin/lihat_pesan" >
              <li class="dropdown messages-menu"> 
                
                  <i class="fa fa-envelope-o"></i>
                  
                </a>
              </li>
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <b>Selamat Datang, </b><span class="hidden-xs"><?php if($id_admin = $this->session->userdata('id_admin')) { ?>
            <?php $data_user = $this->m_admin->get_data2('admin',$id_admin)->row_array(); echo $data_user['nama_lengkap'];?> 
             <?php } ?></span>
                </a>
              </li>
            </ul>
          </div>
        </nav>
      </header>