<!DOCTYPE html>
<html>
<head>
 <title></title>
</head>
<body>
 <style type="text/css">
 .table-data{
   width: 100%;
   border-collapse: collapse;
  }

  .table-data tr th,
  .table-data tr td{
   border:1px solid black;
   font-size: 10pt;
  }
 </style> 

 <h3 align="center">Laporan Data Pengajuan Kredit</h3> 
 <br/>
 <table>
  <tr>
   <td>Dari Tgl</td>
   <td>:</td>
   <td><?php echo date('d/m/Y',strtotime($_GET['dari'])); ?></td>
  </tr>
  <tr>
   <td>Sampai Tgl</td>
   <td>:</td>
   <td><?php echo date('d/m/Y',strtotime($_GET['sampai'])); ?></td>
  </tr>
 </table>

 <br/>
 <table class="table-data">
  <thead>
   <tr>
    <th>No</th>
    <th>TGL PENGAJUAN</th>
    <th>ID APLIKASI</th>
    <th>ID PEMOHON</th>
    <th>NAMA PEMOHON</th>
    <th>ALAMAT</th>
    <th>KODE POS</th>
    <th>NO.TELEPON</th>
    <th>JENIS PEKERJAAN</th>
    <th>PENDAPATAN</th>
    <th>JUMLAH KREDIT</th>
    <th>JANGKA WAKTU</th>
    <th>TUJUAN KREDIT</th>
    <th>AGUNAN</th>
    <th>STATUS</th>
        
   </tr>
  </thead>
  <tbody>
   <?php
   $no = 1;
   foreach($laporan as $a){
   ?>
   <tr>
     <td><?php echo $no++; ?></td>
    <td><?php echo $a->tgl_beli ?></td>
     <td><?php echo $a->id_aplikasi ?></td>
     <td><?php echo $a->id_pemohon ?></td>
     <td><?php echo $a->nama_lengkap ?></td>
     <td><?php echo $a->alamat ?></td>
     <td><?php echo $a->kode_pos ?></td>
     <td><?php echo $a->telp ?></td>
     <td><?php echo $a->jenis_pekerjaan ?></td>
     <td><?php echo $a->pendapatan ?></td>
     <td><?php echo $a->jumlah_kredit ?></td>
     <td><?php echo $a->jangka_waktu ?></td>
     <td><?php echo $a->tujuan_kredit ?></td>
     <td><?php echo $a->jaminan ?></td>
     <td><?php echo $a->status ?></td>
    
     </tr>
   <?php
  }
  ?>


 </tbody>
</table>



<script type="text/javascript">
 window.print();
</script>

</body>
</html>
