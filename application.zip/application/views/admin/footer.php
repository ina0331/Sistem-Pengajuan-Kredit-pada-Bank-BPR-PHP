
    <!-- jQuery 2.1.3 -->
    <script src="<?php echo base_url(); ?>assets1/plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- jQuery UI 1.11.2 -->
    <script src="<?php echo base_url(); ?>assets1/dist/js/jquery-ui.min.js" type="text/javascript"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="<?php echo base_url(); ?>assets1/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>    
    <!-- datepicker -->
    <script src="<?php echo base_url(); ?>assets1/plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets1/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="<?php echo base_url(); ?>assets1/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='<?php echo base_url(); ?>assets1/plugins/fastclick/fastclick.min.js'></script>

    <!-- membuat efek animasi -->
    <script src="<?php echo base_url(); ?>assets1/dist/js/app.min.js" type="text/javascript"></script>

    
    