
<!DOCTYPE html>
<html>
<head>
  <link href="<?php echo base_url(); ?>assets/dist/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
  <?php $this->load->view('admin/head'); ?>
  
</head>
<body class="skin-blue">
  <!-- wrapper di bawah footer -->
  <div class="wrapper">

    <?php $this->load->view('admin/head2'); ?>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
      <?php $this->load->view('admin/sidebar'); ?>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          <b>Cetak Data Pengajuan Kredit</b>
        </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

        <!-- Main content -->
        <section class="content">
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-12">
            <!-- Chat box -->
            <div class="box">
              <div class="box-header">
          
              </div>
              <div class="box-body chat" id="chat-box">
<!-- /. NAV SIDE  -->
       <div class="item">


<form method="post" action="<?php echo base_url().'admin/cetak_pengajuan'?>">
 <div class="form-group">
  <label>Dari Tanggal</label>
  <input type="date" name="dari" class="form-control">
  <?php echo form_error('dari'); ?>
 </div>
 <div class="form-group">
  <label>Sampai Tanggal</label>
  <input type="date" name="sampai" class="form-control">
  <?php echo form_error('sampai'); ?>
 </div>
 <div class="form-group">
  <input type="submit" value="CARI" name="cari" class="btn btn-sm btn-primary">
 </div>
</form>
 <section class="col-lg-5 connectedSortable">

          </section><!-- right col -->
        </div><!-- /.row (main row) -->

      </section><!-- /.content -->
   
    
    <?php $this->load->view('admin/footer'); ?>
</body>
</html>