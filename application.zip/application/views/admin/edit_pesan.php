<!DOCTYPE html>
<html>
<head>
  <link href="<?php echo base_url(); ?>assets/dist/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
  <?php $this->load->view('admin/head'); ?>
  
</head>
<body class="skin-blue">
  <!-- wrapper di bawah footer -->
  <div class="wrapper">

    <?php $this->load->view('admin/head2'); ?>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
      <?php $this->load->view('admin/sidebar'); ?>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          <b>KIRIM PESAN</b>
        </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

        <!-- Main content -->
        <section class="content">
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-12">
            <!-- Chat box -->
            <div class="box">
              <div class="box-header">
                <i class="fa fa-plus"></i>
                <h3 class="box-title">KIRIM PESAN INFO PENCAIRAN DANA</h3>
              </div>
              <div class="box-body chat" id="chat-box">
<!-- /. NAV SIDE  -->
       <div class="item">

<form action="<?php echo base_url().'admin/kirim_pesan' ?>" method="post" enctype="multipart/form-data">



   <div class="form-group">
      <label>Email Pemohon</label>
      <select name="email" class="form-control">
        <option value="">-Pilih Email-</option>
        <?php foreach ($pemohon as $a) { ?>
        <option value="<?php echo $a->email; ?>"><?php echo $a->email; ?></option>
      <?php } ?>
    </select>
      <?php echo form_error('email'); ?>
    </div>

      <div class="form-group">
      <label>Nama Pemohon</label>
      <select name="id_pemohon" class="form-control">
        <option value="">-Nama Pemohon-</option>
        <?php foreach ($pemohon as $a) { ?>
        <option value="<?php echo $a->id_pemohon; ?>"><?php echo $a->nama_lengkap; ?></option>
      <?php } ?>
    </select>
      <?php echo form_error('id_pemohon'); ?>
    </div>



    <div class="form-group">
      <label>Pesan</label>
      <textarea name="subjek" class="form-control" rows="3"></textarea>
        
                                        </div>


 
  <div class="form-group">
    <input type="submit" value="Kirim" class="btn btn-primary">
    <input type="button" value="Kembali" class="btn btn-danger" onclick="window.history.go(-1)">
  </div> 
  </form>

                                                          <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

 

</section>
<section class="col-lg-5 connectedSortable">

          </section><!-- right col -->
        </div><!-- /.row (main row) -->

      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
    <footer class="main-footer">
      <div class="pull-right hidden-xs">
        <!-- <b>Version</b> 2.0 -->
      </div>
      <strong>Copyright &copy; 2020 <a href="#"></a></strong>
    </footer>
  </div><!-- ./wrapper -->
  <!-- page script -->
  

    
    <?php $this->load->view('admin/footer'); ?>
</body>
</html>