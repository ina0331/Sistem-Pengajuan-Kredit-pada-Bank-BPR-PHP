 <!DOCTYPE html>
<html>
  <head>
    <?php $this->load->view('admin/head'); ?>
    <link href="<?php echo base_url(); ?>assets1/dist/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />

  </head>
  <body class="skin-blue">
  <!-- wrapper di bawah footer -->
    <div class="wrapper">
      
      <?php $this->load->view('admin/head2'); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php $this->load->view('admin/sidebar'); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <b>DATA PENGAJUAN KREDIT</b>
          </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

          <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-md-12">
              
              <div class="box">
                <span id="pesan-flash"><?php echo $this->session->flashdata('sukses'); ?></span>
                <span id="pesan-error-flash"><?php echo $this->session->flashdata('alert'); ?></span>
                <div class="box-title">
                  
                </div><!-- /.box-title -->
                <div class="box-body">
                 <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>NO</th>
                      <th>ID APLIKASI</th>
                      <th>ID PEMOHON</th>
                      <th>NAMA PEMOHON</th>
                      <th>TGL PENGAJUAN</th>
                      <th>JENIS PEKERJAAN</th>
                      <th>PENDAPATAN</th>
                      <th>JUMLAH KREDIT</th>
                      <th>JANGKA WAKTU</th>
                      <th>TUJUAN KREDIT</th>
                      <th>ANGSURAN PERBULAN</th>
                      <th>STATUS</th>
                      <th>DETAIL</th>
                      <th>AKSI</th>
                    </tr>
                  </thead>
                  <tbody>
                   
      <?php
      $no = 1;
      foreach ($pengajuan as $a) {
      ?>
                    <tr>
                      <td><?php echo $no++; ?></td>
                      <td><?php echo $a->id_aplikasi ?></td>
                      <td><?php echo $a->id_pemohon ?></td>
                      <td><?php echo $a->nama_lengkap ?></td>
                      <td><?php echo $a->tgl_beli ?></td>
                      <td><?php echo $a->jenis_pekerjaan ?></td>
                      <td>Rp.<?php echo $a->pendapatan ?></td>
                      <td>Rp.<?php echo $a->jumlah_kredit ?></td>
                      <td><?php echo $a->jangka_waktu ?></td>
                      <td><?php echo $a->tujuan_kredit ?></td>
                     <td><?php echo $a->angsuran_perbulan ?></td>
                     <td><?php echo $a->status ?></td>
                      <td><a class="btn btn-sm btn-success" href="<?php echo base_url().'admin/lihat_pengajuan/'.$a->id_aplikasi; ?>">Lihat</a>
   <td><a class="btn btn-primary btn-sm" href="<?php echo base_url().'admin/edit_status/'.$a->id_aplikasi; ?>"><i class="fa fa-pencil"></i></span></a>
          <a class="btn btn-warning btn-sm" href="<?php echo base_url().'admin/hapus_pengajuan/'.$a->id_aplikasi; ?>"><i class="fa fa-trash"></i></a></td>               
                     
                    </tr>
                    <?php } ?>
                  </tbody>
                </table> 
              </div>
            </div><!-- /.box -->
          </div><!-- /.col -->
       


          <!-- right col (We are only adding the ID to make the widgets sortable)-->
          <section class="col-lg-5 connectedSortable">

          </section><!-- right col -->
        </div><!-- /.row (main row) -->

      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
    <footer class="main-footer">
      <div class="pull-right hidden-xs">
        <!-- <b>Version</b> 2.0 -->
      </div>
      <strong>Copyright &copy; 2020 <a href="#"></a></strong>
    </footer>
  </div><!-- ./wrapper -->
  <!-- page script -->
  

    
    <?php $this->load->view('admin/footer'); ?>
    <script src="<?php echo base_url(); ?>assets1/dist/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets1/dist/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <script type="text/javascript">
      $(function() {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": true,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false


        });
      });
            //waktu flash data :v
      $(function(){
      $('#pesan-flash').delay(4000).fadeOut();
      $('#pesan-error-flash').delay(5000).fadeOut();
      });
    </script>
</body>
</html>