<?php $this->load->view($header);?>
<link rel="stylesheet" href="<?=base_url('assets/front-end/plugins/touchspin/css/touchspin.css');?>">
<link rel="stylesheet" href="<?=base_url('assets/front-end/plugins/layerslider/css/layerslider.css');?>">
<?php $this->load->view($menu);?>

<!-- START Item Detail -->
<section class="section bgcolor-white">
    <div class="container"> 
        <!-- START row --> 
        <div class="row">
            <!-- START Carousel -->
            <div class="col-md-6">
                <div id="layerslider" style="width:3000px; height:3500px;">
                    <div class="ls-slide" data-ls="transition2d:73;">
                        <img width="300" height="500" src="<?=base_url('assets/images/perbaikan/profil.jpg');?>" class="ls-bg" alt="Gambar Perbaikan">
                    </div>
                    <div class="ls-slide" data-ls="transition2d:73;">
                        <img src="<?=base_url('assets/images/perbaikan/b.jpg');?>" class="ls-bg" alt="Gambar Perbaikan">
                    </div>
                    <div class="ls-slide" data-ls="transition2d:73;">
                        <img src="<?=base_url('assets/images/perbaikan/c.jpg');?>" class="ls-bg" alt="Gambar Perbaikan">
                    </div>
                    <div class="ls-slide" data-ls="transition2d:73;">
                        <img src="<?=base_url('assets/images/perbaikan/d.jpg');?>" class="ls-bg" alt="Gambar  Perbaikan">
                    </div>
                    <div class="ls-slide" data-ls="transition2d:73;">
                        <img src="<?=base_url('assets/images/perbaikan/f.jpg');?>" class="ls-bg" alt="Gambar Perbaikan">
                    </div>
                </div>
                <div class="mb25 visible-xs visible-sm"></div>
            </div>
            <!--/ END Carousel -->

            <!-- START Detail -->
            <div class="col-md-6">
                <h3 class="section-title font-alt mt0" align="center"><b>Sejarah Perusahaan</b></h3>

                <hr><!-- horizontal line -->

                <h5 class="mb15" align="justify">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bank Pengkreditan Rakyat Wibawa Mukti Jabar merupakan BPR milik pemerintah Provinsi Jawa Barat, Pemerintah Kabupaten Bekasi, Bank Jabar Banten tbk. BPR Wibawa Mukti Jabar merupakan hasil perubahan bentuk badan hukum dari PD. Bank Pengkreditan Rakyat Lembaga Pengkreditan kecamatan Bekasi (PD. BPR LPK Bekasi) dengan keputusan anggota komisioner Otoritas Jasa Keuangan (OJK) NO.KEP.72/D.03/2015/, tanggal 2 November 2015, tentang izin penggabungan (Merger) PD. BPR LPK Pondokgede, Cibitung, Setu, Cibarusah, dan Sukatani.</h5>

                <h5 class="mb15" align="justify">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sejak terbitnya peraturan daerah Provinsi Jawa Barat Nomor 12 tahun 2015 tentang perubahan bentuk hukum perusahaan daerah Bank Pengkreditan Rakyat hasil Marger menjadi alat penggerak roda perekonomian khususnya sector UMKM di kabupaten Bekasi, sehingga mampu berkontribusi menumbuhkan sektor riilyang pada akhirnya dapat memperluas dan mencipkan lapangan kerja bagi masyarakat di kabupaten.</h5>

                <hr><!-- horizontal line -->

            </div>
        
             <div class="col-md-6">
                <h3 class="section-title font-alt mt0"><b>Visi & Misi Perusahaan</b></h3>

                <hr><!-- horizontal line -->

                <h3>VISI</h3>
	<h4><i>"Menjadi Bank Pengkreditan Rakyat yang terbaik di Bidang Mikro Finance"</i></h3>
<h3>MISI</h4>
<p>1.	Mendukung memberikan pelayanan yang cepat dan akurat kepada nasabah</p>
<p>2.	Mendukung pengembangan usaha mikro kecil dan menengah</p>
<p>3.	Menyediakan produk yang sesuai dengan kebutuhan dan selera masyarakat</p>
<p>4.	Memberikan kontribusi yang layaak bagi pemegang saham</p>
<p>5.	Meningkatkan nilai kekayaan pemegang saham dan kesejahteraaan pengurus dan karyawan</p>


                <hr><!-- horizontal line -->

            </div>
            <!--/ END Detail --> 
        </div>
        <!--/ END row -->
    </div>
</section>
<!--/ END Item Detail -->

<?php $this->load->view($footer);?>

<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/layerslider.transitions.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/touchspin/js/jquery.bootstrap-touchspin.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/javascript/frontend/shop/shop-item-detail.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/greensock.js"></script>
 