<?php $this->load->view('user/view_header'); ?>
<link rel="stylesheet" href="<?=base_url('assets/front-end/plugins/steps/css/jquery-steps.css');?>">
<link rel="stylesheet" type="text/css" href="<?=base_url('assets/js/jquery-easyui-1.4.4/themes/black/easyui.css');?>">
<script type="text/javascript" src="<?=base_url('assets/js/jquery-easyui-1.4.4/jquery.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('assets/js/numeral.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('assets/front-end/javascript/backend/forms/wizard.js');?>"></script>

<?php $this->load->view('user/view_menu'); ?>

<!-- START Template Main -->
<section id="main" role="main">
    <!-- START Template Container -->
    <div class="container-fluid">

        <!-- START row -->
        <div class="row">
            <div class="col-md-12">
                <!-- START Panel -->
                <div class="panel panel-default">
                    <!-- panel heading/header -->
                    <div class="panel-heading">
                        <?=br(2);?>
                    </div>
                    <!--/ panel heading/header -->
                    <!-- START Form Wizard -->         
                    <form class="form-horizontal form-bordered" action="<?=site_url('/user/upload_berkas_act');?>" method="post" id="wizard-validate" enctype="multipart/form-data">


                        <!-- Wizard Container 1 -->
                      
                        <!-- Wizard Container 2 -->
                        <div class="wizard-title">UPLOAD BERKAS PRIBADI</div>
                        <div class="wizard-container">
<!--                                     <div class="form-group">
                                <div class="col-md-12">
                                    <h5 class="semibold text-primary nm">Proceed to payment</h5>
                                    <p class="text-muted nm">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                    tempor incididunt ut labore et dolore magna aliqua.</p>
                                </div>
                            </div>
-->
                          <div class="form-group">
                         <p align="center"> <strong>Perhatian!</strong> Anda diwajibkan untuk mengupload data anda, file yang diupload harus beresolusi HD agar memudahkan kami untuk pengecekan.</p>
                         <br>
                  <font color=blue><p align="right"><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  <div class="alert alert-danger alert-success">
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></p></font>
<?php foreach ($aplikasi as $a){ ?>
<div class="form-group">
    <label></label>
    <input type="hidden" name="id" value="<?php echo $a->id_aplikasi; ?>">
    <input type="hidden" name="id_aplikasi" class="form-control" value="<?php echo $a->id_aplikasi; ?>">
    <?php echo form_error('id_aplikasi'); ?>
    </div>
                          </div>
                          <div class="form-group">
                            <label class="col-sm-2 control-label">KTP :</label>
                            <div class="col-sm-4">
                              <input type="file" name="ktp" id="ktp" class="form-control">
                               
                            </div>
                            <label class="col-sm-2 control-label">Kartu Keluarga :</label>
                            <div class="col-sm-4">
                              <input type="file" name="kk" id="kk" class="form-control">
                            </div>
                          </div>

                           <div class="form-group">
                           <label class="col-sm-2 control-label">Pasfoto :</label>
                            <div class="col-sm-4">
                              <input type="file" name="pasfoto" id="pasfoto" class="form-control">
                               
                            </div>
                           <label class="col-sm-2 control-label">NPWP :</label>
                            <div class="col-sm-4">
                                <input type="file" name="npwp" id="npwp" class="form-control">
                            </div>
                          </div>


                           <div class="form-group">
                            <label class="col-sm-2 control-label">Rekening Listrik :</label>
                            <div class="col-sm-4">
                              <input type="file" name="rekening_listrik" id="rek_listrik" class="form-control">
                               
                            </div>
                           
                            <label class="col-sm-2 control-label">Struk Gaji :</label>
                            <div class="col-sm-4">
                              <input type="file" name="struk_gaji" id="struk_gaji" class="form-control">
                               
                            </div>
                           
                          </div>
                           <div class="form-group">
                        <font color=red><small>*max 2 MB, JPG/PNG.</small></font><br>
                         <font color=red align="center"><small>*Saya menyatakan bahwa data yang saya isikan diatas sudah benar.</small></font> 
                       </div>


</div>

  <div class="wizard-title">UPLOAD BERKAS JAMINAN</div>
                        <div class="wizard-container">
                                  <div class="form-group">
                                <div class="col-md-12">
                                    <h5 class="semibold text-primary nm">Harap Upload berkas Agunan sesuai dengan jenis kredit yang dipilih.</h5>
                                    
                                </div>
                            </div>

                          <div class="form-group">
                                <label class="col-sm-2 control-label">Agunan :</label>
                                <div class="col-sm-10">
                                    <select name="jaminan" class="form-control" data-rule="" placeholder="-Pilih-">
                                        <option value="Sertifikat HGB/HM">Sertifikat HGB/HM</option>
                                        <option value="BPKB">BPKB Mobil/Motor</option>
                                         <option value="Lainnay">Lainnya</option>
                                        </select>
                                    </div>
                                </div>
                          <div class="form-group">
                            <label class="col-sm-2 control-label">Berkas Agunan :</label>
                            <div class="col-sm-4">
                              <input type="file" name="berkas_agunan" id="berkas_agunan" class="form-control">
                               
                            </div>
                           
                          </div>
                            <div class="form-group">
                   
                         <font color=red align="center"><p>*Saya menyatakan bahwa data yang saya isikan diatas sudah benar.</p></font> 
                       </div>


</div>


                    <!-- Wizard Container 4 -->

                    </form>
                            <?php } ?>
                    <!--/ END Form Wizard --> 
                </div>
                <!--/ END Panel -->
            </div>
        </div>
        <!--/ END row --> 

    <!-- START To Top Scroller -->
    <a href="#" class="totop animation" data-toggle="waypoints totop" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="50%"><i class="ico-angle-up"></i></a>
    <!--/ END To Top Scroller -->
</section><br><br><br>
<!--/ END Template Main -->
<?php $this->load->view('user/view_footer');?>
<!-- Plugins and page level script : optional -->
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/steps/js/jquery-steps.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/parsley/js/parsley.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/inputmask/js/inputmask.js"></script>
<script type="text/javascript" src="<?=base_url('assets/js/jquery-easyui-1.4.4/jquery.easyui.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('assets/js/jquery-easyui-1.4.4/jquery.easyui.mobile.js');?>"></script>
<!--/ Plugins and page level script : optional -->
<!--/ END JAVASCRIPT SECTION -->