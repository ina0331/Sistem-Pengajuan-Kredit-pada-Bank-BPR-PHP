 <?php $this->load->view($header);?>
 <?php $this->load->view($menu);?>
 <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12"><div class="page-header">
	<h3 align="center"><b>Profil Diri</b> </h3>
</div>
<div style="position: relative; right: : 25%">
<table align="center">
	<?php
	// echo print_r($siswa);
		foreach ($user as $e) {
	?>
	<tr><th>&nbsp;&nbsp;Nama Nasabah</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->nama_lengkap; ?></th></tr>
	<tr><th>&nbsp;&nbsp;Username</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->username; ?></th></tr>
	<tr><th>&nbsp;&nbsp;No.Telepon</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->no_telp; ?></th></tr>
	<tr><th>&nbsp;&nbsp;Email</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->email; ?></th></tr>
	<tr><th>&nbsp;&nbsp;Alamat</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->alamat; ?></th></tr>
	<tr><th>&nbsp;&nbsp;Foto</th><th>&nbsp;:&nbsp;</th><th><img src="<?php echo base_url();?>assets/upload/<?=$e->foto;?>" style="max-width:100%; max-height: 100%; height: 150px; width: 120px"></th></tr> 
	&nbsp;&nbsp;<tr><th>&nbsp;&nbsp;<a class="btn btn-primary btn-block btn-flat" href="<?php echo base_url().'Home/edit_profil/'.$e->id_pemohon; ?>">Edit Profil</th></tr>
	<?php } ?>
				</tbody>
				</table>

	<tr><td colspan="3"><hr></td></tr>
	
</table>
</div>
</div>

                                                              <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>


<?php $this->load->view($footer);?>
