        <!-- START Template Footer -->
        <footer role="contentinfo" class="bgcolor-dark pt25">
            <!-- container -->
            <div class="container mb25">
                <!-- row -->
                <div class="row">
                    <!-- About -->
                    <div class="col-md-4">
                        <h4 class="font-alt mt0">PROFIL</h4>
                        <p align="justify">Bank Perkreditan rakyat Wibawa Mukti Jabar merupakan BPR Milik Pemerintah Provinsi Daerah Jawa barat, Pemerintah Kabupaten Bekasi, Bank Jabar Banten tbk. BPR Wibawa Mukti Jabar merupakan hasil ..
                        <a href="<?=site_url('/home/about');?>" class="text-primary">Read more</a></p>
                    </div>
                    <div class="visible-sm visible-xs" style="margin-bottom:25px;"></div>
                    <!--/ About -->

                    <!-- Address + Social -->
                    <div class="col-md-4" style="background: url('<?=base_url();?>assets/front-end/image/others/map-vector.png') no-repeat center center;background-size: 100%;">
                        <h4 class="font-alt mt0">ALAMAT</h4>
                        <address>
                            Jl. Raya Loji Komplek kantor Kecamatan<br>
                            Desa Cibarusah Kota Kec.Cibarusah<br>
                            Kab.Bekasi Jawa Barat - 17340<br>
                            <abbr title="Phone">Telp:</abbr> 021-89952714<br>
                            <abbr title="Email">Email:</abbr> wmjcbr@gmail.com
                        </address>
                    </div>
                    <div class="visible-sm visible-xs" style="margin-bottom:25px;"></div>
                    <!--/ Address + Social -->

                    <!-- Newsletter -->
                    <div class="col-md-4">
                        <h4 class="font-alt mt0">IKUTI KAMI :</h4>
                         
                            <div>
                               <a href="https://web.facebook.com/pt.bprwmj/"><img src="<?= base_url();?>assets/img/facebook.jpg" width="45" height="45"></a>&nbsp;
                                 <a href="https://www.instagram.com/pt.bprwmj/"><img src="<?= base_url();?>assets/img/instagram.jpg" width="45" height="45"></a>&nbsp;
                                  <a href="#"><img src="<?= base_url();?>assets/img/twitter.jpg" width="45" height="45"></a>&nbsp;
                                  <!-- <a href="#"><img src="<?= base_url();?>assets/img/Gmail-logo.jpg" width="50" height="42"></a>&nbsp; -->
                            </div>
                        
                    </div>
                    <!--/ Newsletter -->
                </div>
                <!--/ row --> 
            </div>
            <!--/ container -->

            <!-- bottom footer -->
            <div class="footer-bottom pt15 pb15 bgcolor-dark bgcolor-dark-darken10">
                <!-- container -->
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6">
                            <!-- copyright -->
                            <p class="nm text-muted">&copy; Copyright 2020 by <a href="<?=site_url();?>" class="text-white">Rohimah Muthmainnah</a>. All Rights Reserved.</p>
                            <!--/ copyright -->
                        </div>
                        <div class="col-sm-6 text-right hidden-xs">
                            <a href="javascript:void(0);" class="text-white">Privacy Policy</a>
                            <span class="ml5 mr5">&#8226;</span>
                            <a href="javascript:void(0);" class="text-white">Terms of Service</a>
                        </div>
                    </div>
                </div>
                <!--/ container -->
            </div>
            <!--/ bottom footer -->
        </footer>
        <!--/ END Template Footer -->
        
        <!-- START JAVASCRIPT SECTION (Load javascripts at bottom to reduce load time) -->
        <!-- Application and vendor script : mandatory -->
        <script type="text/javascript" src="<?=base_url();?>assets/front-end/javascript/vendor.js"></script>
        <script type="text/javascript" src="<?=base_url();?>assets/front-end/javascript/core.js"></script>
        <script type="text/javascript" src="<?=base_url();?>assets/front-end/javascript/frontend/app.js"></script>
        <!--/ Application and vendor script : mandatory -->

        <!-- Plugins and page level script : optional -->
        <script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/smoothscroll/js/smoothscroll.js"></script>
        <!--/ Plugins and page level script : optional -->
        <!--/ END JAVASCRIPT SECTION -->
    </body>
    <!--/ END Body -->
</html>