<?php $this->load->view($header);?>
<?php $this->load->view($menu);?>

<!-- START Big Google Maps -->
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3964.638215015123!2d107.07869461477024!3d-6.440484095340426!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6997e90bffa011%3A0xa6aec25ff475f20!2sPT.%20BPR%20CIBARUSAH%20WIBAWA%20MUKTI%20JABAR!5e0!3m2!1sid!2sid!4v1592399715125!5m2!1sid!2sid" width="1500" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
<!--/ END Big Google Maps --> 

<!-- START Contact Form + Infos -->
<section class="section bgcolor-white">
    <div class="container">
        <!-- START Row -->
        <div class="row">
            <!-- START Left Section -->
            <div class="col-md-9">
                <!-- Form -->
              
                <h3 class="section-title font-alt mt0">Buku Tamu</h3>
                <font color=blue><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></font>
                <form class="form-horizontal" action="<?php echo base_url().'home/buku_tamu' ?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <div class="col-sm-6">
                            <label for="contact_name" class="control-label">Nama <span class="text-danger">*</span></label>
                            <input type="text" name="nama_lengkap" class="form-control" id="contact_name" required>
                        </div>
                    </div> 
                    <div class="form-group">
                        <div class="col-sm-6">
                            <label for="contact_email" class="control-label">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control" id="contact_email" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <label for="contact_email" class="control-label">Pesan Anda <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="pesan" rows="6" id="contact_message" required></textarea>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Kirim Pesan</button>
                </form>
                <!--/ Form -->

                <div class="mb15 visible-xs visible-sm"></div>
            </div>
            <!--/ END Left Section -->
            
            <!-- START Right Section -->
            <div class="col-md-3">

                <!-- Address -->
                <div class="pt25 mb25">
                    <!-- Title -->
                    <h4 class="section-title font-alt mt0"><img src="<?= base_url();?>assets/img/home.png" width=15% height=15%> Alamat</h4>
                    <!--/ Title -->
                    <address>
                        Jl.Raya Loji Komplek kantor Kecamatan<br>
                        Desa Cibarusah Kota Kec.Cibarusah<br>
                        Kab.Bekasi Jawa Barat - 17340 <br>
                    </address>

                    <!-- Title -->
                    <h4 class="section-title font-alt mt0"><img src="<?= base_url();?>assets/img/download.png" width=15% height=15%> Jam Kerja</h4>
                    <!--/ Title -->
                    <ul class="list-unstyled">
                        <li><strong>Senin - Jumat :</strong> 08.00 - 15.00</li>
                        <li><strong>sabtu - Minggu:</strong> Tutup</li>
                    </ul>

                     <br>

                    <h4 class="section-title font-alt mt0"><img src="<?= base_url();?>assets/img/download.jpg" width=15% height=15% /> KONTAK </h4>
                    <!--/ Title -->
                    <ul class="list-unstyled">
                        <li><strong> 021-89952714 </strong><i>(Telp Office)</i></li>
                        <li><strong> 0852-8393-4947 </strong><i> (Contact Person)</i></li>
                        </ul>
                </div>
                <!--/ Business Hour -->

            </div>
            <!--/ END Right Section -->
        </div>
        <!--/ END Row -->
    </div>
</section>
<!--/ END Contact Form + Infos -->

<?php $this->load->view($footer);?>

