<?php $this->load->view($header);?>
<link rel="stylesheet" href="<?=base_url('assets/front-end/plugins/touchspin/css/touchspin.css');?>">
<link rel="stylesheet" href="<?=base_url('assets/front-end/plugins/layerslider/css/layerslider.css');?>">
<?php $this->load->view($menu);?>

<!-- START Item Detail -->
<section class="section bgcolor-white">
    <div class="container"> 
        <!-- START row --> 
      
            <!-- START Carousel -->
             <div class="col-md-6">
                <h2 align="center"> Prosedur Pengajuan Kredit :</h2>

                <hr><!-- horizontal line -->

    <h4>     1. Pemohon harus melakukan Login terlebih dahulu.</h4>
    <h4>     2. Pemohon memilih menu "Aplikasi Pengajuan Kredit".</h4>
    <h4>     3. Pemohon mengisi Aplikasi Formulir Pengajuan Kredit.</h4>
    <h4>     4. Pastikan semua berkas sudah dalam bentuk foto</h4>
    <h4>     5. Berkas yang diminta adalah KTP, KK, Pasfoto, NPWP, Rekening listrik, Struk Gaji, dan Berkas Agunan.</h4>
    <h4>     6. Pemohon Mengupload Berkas-berkas yang diminta.</h4>
    <h4>     7. Pemohon mencetak <b><i>"Bukti Pengajuan".</i></b></h4>
    <h4>     8. Jika pemohon memenuhi persyaratan, pihak BPR WMJ akan menginfokan pencairan dana melalui E-mail kepada pemohon. </h4>
    <h4>     9. Pemohon dapat melihat status pengajuan dimenu <b><i>"Status Pengajuan".</i></b></h4>

                <hr><!-- horizontal line -->
</div>
<div>

            <div class="col-md-6">
                <!-- Iframe container -->
                <img src="<?= base_url();?>assets/images/alur_pendaftaran.jpg" width=120% height=120% /></img>
                </div>
                <!--/ Iframe container -->
            </div>
        </div>
            <!--/ END Detail -->
   
    </div>
</section>
<!--/ END Item Detail -->

<?php $this->load->view($footer);?>

<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/layerslider.transitions.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/touchspin/js/jquery.bootstrap-touchspin.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/javascript/frontend/shop/shop-item-detail.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/greensock.js"></script>
 