 <?php $this->load->view($header);?>
 <?php $this->load->view($menu);?>
 <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12"><div class="page-header">
	<h3 align="center"><b>Status Pengajuan Kredit</b> </h3>
</div>
<div style="position: relative; right: : 25%">
<table align="center">
	<?php
	
		foreach ($pengajuan as $e) {
	?>
	<tr><th>&nbsp;&nbsp;ID Formulir Pengajuan</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->id_aplikasi; ?></th></tr>
	<tr><th>&nbsp;&nbsp;ID Pemohon</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->id_pemohon; ?></th></tr>
	<tr><th>&nbsp;&nbsp;Nama Pemohon</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->nama_lengkap; ?></th></tr>
	<tr><th>&nbsp;&nbsp;Jumlah Pengajuan Kredit</th><th>&nbsp;:&nbsp;</th><th>Rp.<?php echo $e->jumlah_kredit; ?></th></tr>
	<tr><th>&nbsp;&nbsp;Jangka Waktu</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->jangka_waktu; ?></th></tr>
	<tr><th>&nbsp;&nbsp;Angsuran Perbulan</th><th>&nbsp;:&nbsp;</th><th>Rp.<?php echo $e->angsuran_perbulan; ?></th></tr>
	<tr><th>&nbsp;&nbsp;Status</th><th>&nbsp;:&nbsp;</th><th><pre><?php echo $e->status; ?></pre></th></tr>
	 
	<?php } ?>
				</tbody>
				</table>

	<tr><td colspan="3"><hr></td></tr>
	
</table>
</div>
</div>
 
                                                              <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>


<?php $this->load->view($footer);?>
