<?php $this->load->view($header);?>
<link rel="stylesheet" href="<?=base_url('assets/front-end/plugins/touchspin/css/touchspin.css');?>">
<link rel="stylesheet" href="<?=base_url('assets/front-end/plugins/layerslider/css/layerslider.css');?>">
<?php $this->load->view($menu);?>

<!-- START Item Detail -->
<section class="section bgcolor-white">
    <div class="container"> 
        <!-- START row --> 
      
            <!-- START Carousel -->
              <div class="col-md-6"> 
                <font color="blue"><h3><b> PERSYARATAN KREDIT UMUM :</b></font></h3>
<p>1. KTP</p>
<p>2. Kartu Keluarga</p>    
<p>3. Pasfoto</p>
<p>4. Surat Keterangan Pendapatan (jika tidak ada Slip gaji) </p>
<p>5. Jika alamat rumah tidak sesuai KTP, Harus disertakan Surat Keterangan Domisili</p>
<p></p>
<br>
<font color="blue"><h3><b> KREDIT MODAL KERJA :</b></font></h3>
<p>1. Surat Tanah berupa sertifikat Tanah/AJB</p>
<p>2. BPKB Kendaraan dan STNK</p>    
<p></p>
<br>
<font color="blue"><h3><b> KREDIT MULTIGUNA :</b></font></h3>
<p>1. Slip Gaji 2-3 bulan terakhir</p>
<p>2. BPKB Kendaraan dan STNK</p>    
<p>3. Kartu JAMSOSTEK/ BPJS Ketenagakerjaan</p> 
<p></p>
<br>

                <hr><b><!-- horizontal line -->
</div>
<div>

            <div class="col-md-6">
                <!-- Iframe container -->
<font color="blue"><h3><b> KREDIT SERTIFIKAT :</b></font></h3>
<p>1. SERTIFIKAT SERTIFIKASI</p>
<p>2. SKGol Terakhir</p>    
<p>3. ATM Penerima Tunjangan</p>
<p></p>
<br>
<font color="blue"><h3><b> KREDIT KONSUMTIF LAINNYA :</b></font></h3>
<p>1. SK Gol Terakhir</p>
<p>2. Surat Keterangan Aktif Bekerja</p>    

<p></p>
<br>
                </div>
                <!--/ Iframe container -->
            </div>
        </div>
            <!--/ END Detail -->
   
    </div>
</section>


<?php $this->load->view($footer);?>

<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/layerslider.transitions.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/touchspin/js/jquery.bootstrap-touchspin.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/javascript/frontend/shop/shop-item-detail.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/greensock.js"></script>
 