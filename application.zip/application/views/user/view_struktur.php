<?php $this->load->view('user/view_header'); ?>
<script src="<?=base_url();?>assets/js/jquery-2.0.3.min.js"></script>
<!--
<script>
$(document).ready(function(){
//ambil id/nilai PROVINSI dan kirim ke function getkota jika sukses ambil data getkota letakan di #kota dan #kota1
  $("#provinsi").change(function(){
    var key = $("#provinsi").val();
    var url = '<?=site_url();?>/home/getKota/'+key;


    $.ajax({
      type    : 'POST',
      url     : '<?=site_url();?>/home/getKota/'+key,
      success : function(){
        $.get(url).done(function(data){
          $("#kota").html(data);
            });
      }
    });
  });
});
</script>-->
<?php $this->load->view('user/view_menu'); ?>

            <!-- START Register Content -->
            <section class="section">
                <div class="container">
                    <!-- START Section Header -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="section-header text-center">
                                <h1 class="section-title font-alt mb25" align="text-center">STRUKTUR ORGANISASI</h1>
                                
                                        <img src="<?= base_url();?>assets/img/struktur.jpg" width="1200" height="500">
                                    </div>
                                </div>
                         
                      
                   
                </div>
            </section>
            <!--/ END Register Content -->

<?php $this->load->view('user/view_footer'); ?>
