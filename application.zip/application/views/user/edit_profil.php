<?php $this->load->view($header);?>
 <?php $this->load->view($menu);?>
 <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12"><div class="page-header">
	<h3 align="center"><b>Edit Profil Diri</b> </h3>
</div>
<div style="position: relative; right: : 50%">
<table align="center">
	
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-12">
            <!-- Chat box -->
            <div class="box">
              <div class="box-header">
                
              </div>
              <div class="box-body chat" id="chat-box">
<!-- /. NAV SIDE  -->
       <div class="item">
<?php foreach ($pemohon as $a){ ?>
<form action="<?php echo base_url().'Home/update_profil' ?>" method="post" enctype="multipart/form-data">


  <div class="form-group">
      <label> &nbsp;&nbsp;Nama Pemohon</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="text" name="nama_lengkap" class="form-control" value="<?php echo $a->nama_lengkap; ?>">
      <?php echo form_error('nama_lengkap'); ?>
    </div>


    <div class="form-group">
      <label> &nbsp;&nbsp;username</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="md5" name="username" class="form-control" value="<?php echo $a->username; ?>">
      <?php echo form_error('username'); ?>
    </div>

     <div class="form-group">
      <label> &nbsp;&nbsp;password</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="password" name="password" class="form-control" value="<?php echo $a->password; ?>">
      <?php echo form_error('password'); ?>
    </div>

<div class="form-group">
      <label> &nbsp;&nbsp;No.telepon</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="number" name="no_telp" class="form-control" value="<?php echo $a->no_telp; ?>">
      <?php echo form_error('no_telp'); ?>
    </div>

 <div class="form-group">
      <label> &nbsp;&nbsp;Email</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="id" name="email" class="form-control" value="<?php echo $a->email; ?>">
      <?php echo form_error('email'); ?>
    </div>

  <div class="form-group">
      <label> &nbsp;&nbsp;Alamat</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <input type="textarea" name="alamat" class="form-control" value="<?php echo $a->alamat; ?>" style="height:100px" >
      <?php echo form_error('alamat'); ?>
    </div>

     <div class="form-group">
      <label> &nbsp;&nbsp;Foto Profil</label>
      <input type="hidden" name="id" value="<?php echo $a->id_pemohon; ?>">
      <img src="<?php echo base_url();?>assets/upload/<?=$a->foto;?>" style="max-width:100%; max-height: 100%; height: 120px; width: 120px">
      <input type="file" name="foto" class="form-control" value="<?php echo $a->foto; ?>">
      <?php echo form_error('foto'); ?>
    </div>

 
  <div class="form-group">
    <input type="submit" value="Update" class="btn btn-primary btn-block btn-flat">
    <input type="button" value="Kembali" class="btn btn-warning btn-block btn-flat" onclick="window.history.go(-1)">
  </div>
  </form>

                                                          <div>
                                                        </div>
                                                    </div>
                                                </div>
                                  
  <?php } ?>

  </section>
  <section class="col-lg-5 connectedSortable">

          </section><!-- right col -->
        </div><!-- /.row (main row) -->

      </section><!-- /.content -->
  </tbody>
				</table>

	<tr><td colspan="3"><hr></td></tr>
	
</table>
</div>
</div>

                                                              <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>


<?php $this->load->view($footer);?>
