<?php $this->load->view($header);?>
<?php $this->load->view($menu);?>

        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12"><div class="page-header">
	<h3 align="center"><b>CETAK BUKTI PENGAJUAN</b> </h3>
</div>
<p align="center"> <a class="btn btn-primary btn-small" href="<?php echo base_url().'home/cetak_pendaftaran' ?>">
  <span class="glyphicon glyphicon-print"></span>
Cetak Print</a></p>
<br>
<br>
<pre align="center"><strong>*Pihak kami akan menghubungi anda melalui email apabila pengajuan tersebut disetejui.</strong></pre>
<pre align="center"><strong>*Harap tandatangan bukti pengajuan ini serta bawa saat tandatangan perjanjian kredit dikantor BPR WMJ Cabang Cibarusah, Terima kasih</strong></pre>

</div>
</div>
</div>
</div>
<br>
<br>
<?php $this->load->view($footer);?>
