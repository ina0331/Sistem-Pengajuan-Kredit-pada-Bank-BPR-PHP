<?php $this->load->view($header);?>
<!-- Plugins stylesheet : optional -->
<link rel="stylesheet" href="<?=base_url();?>assets/front-end/plugins/owl/css/owl-carousel.css">
<link rel="stylesheet" href="<?=base_url();?>assets/front-end/plugins/layerslider/css/layerslider.css">
<link rel="stylesheet" href="<?=base_url();?>assets/front-end/plugins/magnific/css/magnific.css">
<?php $this->load->view($menu);?>

        <!-- START Template Main -->
        <section id="main" role="main">
            <!-- START Layerslider -->
            <section id="layerslider"style="width:100%; height:553px;">
                <!-- Slide #1 -->
                <div class="ls-slide" data-ls="transition2d:1; slidedelay:8000;">
                    <!-- slide background -->
                    <img src="<?=base_url();?>assets/front-end/image/layerslider/bg3.png" class="ls-bg">
                    <!--/ slide background -->
 
                    <!-- Layer #1 -->
                  <img class="ls-l" style="top:40px;left:73%;" src="<?=base_url();?>assets/front-end/image/layerslider/layer/money.png" data-ls="delayin:1000; easingin:easeOutElastic;">
                <!--/ Layer #1 -->
 
                    <!-- Layer #2 -->
                 <h1 class="ls-l font-alt" style="top:110px;left:150px;" data-ls="offsetxin:0;durationin:2000;delayin:1500;easingin:easeOutElastic;rotatexin:-90;transformoriginin:50% top 0;offsetxout:-200;durationout:1000;">
                        ANDA BUTUH <span class="text-primary">DANA ??</span> 
                    </h1>
                                        <!--/ Layer #2 -->

                    <!-- Layer #3 -->
     <h3 class="ls-l" style="top:170px;left:150px;width:550px;" data-ls="offsetxin:0; durationin:2000; delayin:2000; easingin:easeOutElastic; rotatexin:90; transformoriginin:50% top 0; offsetxout:-400;">
                     <b>  BPR Wibawa Mukti Jabar Solusinya !! 
                    </h3></b>
                                        <!--/ Layer #3 -->

                    <!-- Layer #4 -->
     <p class="ls-l text-default" style="top:230px;left:150px;width:550px;" data-ls="offsetxin:0; durationin:2000; delayin:2500; easingin:easeOutElastic; rotatexin:90; transformoriginin:50% top 0; offsetxout:-400;">
                        Kami ada untuk anda. Membantu kebutuhan Konsumtif dan Usaha mikro kecil maupun menengah.
                        Prosesnya cepat, bunganya ringan, syaratnya mudah.
                       <p class="ls-l text-default" style="top:280px;left:150px;width:550px;" data-ls="offsetxin:0; durationin:2000; delayin:2500; easingin:easeOutElastic; rotatexin:90; transformoriginin:50% top 0; offsetxout:-400;"><b>  AYO TUNGGU APA LAGI ? </b>
                    </p>
                                        <!--/ Layer #4 -->

                    <!-- Layer #5 -->
   <a href="<?=site_url('/home/daftar');?>"  class="ls-l btn btn-primary" style="top:310px; left:150px;" data-ls="offsetxin:0; durationin:2000; delayin:3000; easingin:easeOutElastic; rotatexin:90; transformoriginin:50% top 0; offsetxout:-400;"> 
                        Daftar Sekarang <i class="ico-angle-right ml5"></i>
                    </a>
                    <!--/ Layer #5 -->

                    <!-- Layer #6 -->
                     <img class="ls-l" style="top:320px;left:300px;" src="<?=base_url();?>assets/front-end/image/layerslider/layer/arrow.png" data-ls="delayin:3500; offsetxin:0; offsetyin:-30; easingin:easeOutElastic;">
                    <!--/ Layer #6 --> 
                </div>
                <!-- Slide #1 -->

                <!-- Slide #2 -->
                                 <div class="ls-slide" data-ls="transition2d:1; slidedelay:8000;">
         <!-- slide background -->
                     <img src="<?=base_url();?>assets/front-end/image/layerslider/bg2.png" class="ls-bg" alt="Slide background">
                                        <!--/ slide background -->
                    
                    <!-- Layer #1 -->
    <h4 class="ls-l text-default text-right" style="top:120px;left:65%;width:550px;" data-ls="easingin:easeOutElastic; delayin:0;">
                        Selamat datang di
                    </h4>
                    <!--/ Layer #1 -->

                    <!-- Layer #2 -->
                     <h1 class="ls-l font-alt text-right" style="top:150px;left:65%;width:550px;" data-ls="easingin:easeOutElastic; delayin:500;">
                        <span class="text-primary">BPR WIBAWA</span> MUKTI JABAR
                    </h1>
                    <!--/ Layer #2 -->

                    <!-- Layer #3 -->
                     <p class="ls-l text-default text-right" style="top:210px;left:65%;width:550px;" data-ls="easingin:easeOutElastic; delayin:1000;">
                        Bank milik pemerintah daerah Bekasi. PT. BPR Wibawa Mukti Jabar memberikan kredit pada sektor Usaha Kecil Menengah & pegawai Negri Sipil (PNS) maupun Karyawan instansi Swasta.
                    </p>
                     <h3 class="ls-l text-default text-right" style="top:290px;left:65%;width:550px;" data-ls="easingin:easeOutElastic; delayin:1000;"><b> BANK SAHABAT ANAK NEGERI</b></h3>
                   <!--/ Layer #3 -->

                    <!-- Layer #5 -->
                     <p class="ls-l text-default text-right" style="top:350px;left:65%;width:550px;" data-ls="easingin:easeOutElastic; delayin:1500;">
                        <a href="<?=site_url('/home/daftar');?>"  class="btn btn-primary">
                            Daftar Sekarang <i class="ico-angle-right ml5"></i>
                        </a>
                    </p>
                     <!--/ Layer #5 -->

                    <!-- Layer #6 -->
                     <img class="ls-l" width="600" height="700" style="top:0px;left:0px;" src="<?=base_url();?>assets/front-end/image/layerslider/layer/cs2new.png" data-ls="delayin:2000; easingin:easeOutElastic;">
                    <!--/ Layer #6 -->
<!--                  </div>
 -->                <!-- Slide #2 -->
            </section>
            <!--/ END Layerslider -->

            <!-- START Features Section -->
            <section class="section bgcolor-white">
                <div class="container">
                    <!-- START Section Header -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="section-header text-center">
                                <h1 class="section-title font-alt mb25">Layanan Kami</h1>
                            </div>
                        </div>
                    </div>
                    <!--/ END Section Header -->

                    <!-- START row -->
                    <div class="row">
                        <div class="col-md-4"> 
                            <div class="table-layout animation" data-toggle="waypoints" data-showanim="fadeInRight" data-trigger-once="true">
                                <div class="col-xs-2 valign-top"><img src="<?=base_url('assets/front-end/image/icons/costperimpression.png');?>" width="100%" alt=""></div>
                                <div class="col-xs-19 pl15">
                                    <h4 class="font-alt">Kredit Cepat dan Murah</h4>
                                    <p class="nm">Dukungan dan layanan penuh untuk Anda.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="table-layout animation" data-toggle="waypoints" data-showanim="fadeInRight" data-trigger-once="true">
                                <div class="col-xs-2 valign-top"><img src="<?=base_url('assets/front-end/image/icons/supportservices.png');?>" width="100%" alt=""></div>
                                <div class="col-xs-10 pl15">
                                    <h4 class="font-alt">Support Service</h4>
                                    <p class="nm">Kami siap membantu melayani pertanyaan serta menerima dengan baik kritik dan saran anda.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="table-layout animation" data-toggle="waypoints" data-showanim="fadeInRight" data-trigger-once="true">
                                <div class="col-xs-2 valign-top"><img src="<?=base_url('assets/front-end/image/icons/targetaudience.png');?>" width="100%" alt=""></div>
                                <div class="col-xs-10 pl15">
                                    <h4 class="font-alt">Social Public Economi</h4>
                                    <p class="nm">Melayani semua kalangan ekonomi masyarakat khususnya kalangan menengah kebawah.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/ END row -->

                    <!-- START row -->
                    <div class="row">
                        <div class="col-md-4">
                            <div class="table-layout animation mb0" data-toggle="waypoints" data-showanim="fadeInLeft" data-trigger-once="true">
                                <div class="col-xs-2 valign-top"><img src="<?=base_url('assets/front-end/image/icons/socialmediacloud.png');?>" width="100%" alt=""></div>
                                <div class="col-xs-19 pl15">
                                    <h4 class="font-alt">Sosial Media</h4>
                                    <p class="nm">selalu membagikan informasi terbaru kami disosial media.</p>
                                </div>
                            </div>
                        </div>
                        <div class="mb15 visible-xs visible-sm"></div>
                        <div class="col-md-4">
                            <div class="table-layout animation mb0" data-toggle="waypoints" data-showanim="fadeInLeft" data-trigger-once="true">
                                <div class="col-xs-2 valign-top"><img src="<?=base_url('assets/front-end/image/icons/localseo.png');?>" width="100%" alt=""></div>
                                <div class="col-xs-10 pl15">
                                    <h4 class="font-alt">Location</h4>
                                    <p class="nm">kami memiliki cabang lainnya yang terdepat dibeberapa daerah Bekasi.</p>
                                </div>
                            </div>
                        </div>
                        <div class="mb15 visible-xs visible-sm"></div>
                        <div class="col-md-4">
                            <div class="table-layout animation mb0" data-toggle="waypoints" data-showanim="fadeInLeft" data-trigger-once="true">
                                 <div class="col-xs-2 valign-top"><img src="<?=base_url('assets/front-end/image/icons/brandprotection.png');?>" width="100%" alt=""></div>
                                <div class="col-xs-10 pl15">
                                    <h4 class="font-alt">Resmi dan Aman</h4>
                                    <p class="nm">Dibawah pengawasan Bank Indonesia, OJK, dan LPS.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/ END row -->
                </div>
            </section>
            <!--/ END Features Section -->

            <!-- START Shop Content -->
            <section class="section bgcolor-white">
                <div class="container">
                    <!-- START Section Header -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="section-header text-center">
                               
                                <div class="row">
                                    <div class="col-md-8 col-md-offset-2">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--/ END Section Header --

                    <div class="row" id="shuffle-grid">
                        <?php
                            $query = $this->db->get('kategori')->num_rows();
                            for($i=0; $i < $query; $i++):
                                 $data = $this->Model_produk->getProduk($i+1);
                                 foreach($data->result() as $row):
                                    $kategori = $this->Model_kategori->getData($i+1);
                                    $gambar = explode(',', $row->gambar);
                                    if($row->id_kategori == 4)
                                    {
                                        $disabled = 'disabled';
                                    }
                                    else
                                    {
                                        $disabled = '';
                                    }
                        ?>
                        <div class="col-sm-4 shuffle" data-groups='["<?=$kategori->row()->kategori;?>"]'>
                            <div class="panel no-border overflow-hidden">
                                <!-- thumbnail --
                                <div class="thumbnail nm">
                                    <!-- media --
                                    <div class="media">
                                        <!-- indicator --
                                        <div class="indicator"><span class="spinner"></span></div>
                                        <!--/ indicator --

                                        <img data-toggle="unveil" src="<?=base_url();?>assets/front-end/image/shop/placeholder.jpg" data-src="<?=base_url('assets/images/produk/'.$gambar[0]);?>" alt="Photo" width="100%" />

                                    </div>
                                    <!--/ media --
                                </div>
                                <!--/ thumbnail --
                                <!-- Meta --
                                <div class="panel-footer" style="padding:25px;border:0;">
                                    <h4 class="text-center mt0"><?=$row->judul;?></h4>
                                    <h3 class="font-alt text-center text-accent mt0"><?=number_format($row->harga,0, '', '.');?></h3>
                                </div>
                                <div class="panel-footer" style="padding:15px 25px;">
                                    <ul class="list-table">
                                        <li class="text-left">
                                            <form action="<?=site_url('/pesanan/add_to_cart/'.$row->id_produk);?>" method="POST">
                                                <input type="hidden" name="qty" value="1">
                                                <button type="submit" class="btn btn-primary" <?=$disabled;?>>
                                                    <i class="ico-cart-add fsize14">&nbsp;&nbsp;Beli</i>
                                                </button>
                                            </form>
                                        </li>
                                        <li class="text-right">
                                            <a href="<?=site_url('/home/item_detail/'.$row->id_produk);?>" class="btn btn-link text-default"><i class="ico-list-ul fsize14"></i>&nbsp;&nbsp;Detail Produk</a>
                                        </li>
                                    </ul>
                                </div>
                                <!--/ Meta --
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endfor; ?>
                    </div>
                    <!-- START Section Header -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="section-header text-center">
                                <h1 class="section-title font-alt mb25">DIBAWAH PENGAWASAN</h1>
                            </div>
                        </div>
                    </div>
                    <!--/ END Section Header -->

                    <!-- carousel -->
                    <div class="owl-carousel" id="lovely-client">
                        <!-- client #1 -->
                        <div class="item text-left">
                            <a href="javascript:void(0);"><img width="220" height="90" src="<?=base_url('assets/images/patner/ojk.jpg');?>" alt="BI Logo"></a>
                        </div>
                        <!--/ client #1 -->
                        <!-- client #2 -->
                        <div class="item text-center">
                             <a href="javascript:void(0);">  &nbsp;
  &nbsp;<img width="220" height="90" center="50" src="<?=base_url('assets/images/patner/bi.png');?>"  alt="Meitrack Logo"></a>
                        </div>
                        <!--/ client #2 -->
                        <!-- client #3 -->
                         <div class="item text-right">
                            <a href="javascript:void(0);"><img width="200" height="120" src="<?=base_url('assets/images/patner/lps.jpg');?>" alt="Topflytech Logo"></a>
                        </div>
                        <div class="item text-right">
                            <a href="javascript:void(0);">&nbsp;&nbsp;<img width="180" height="120" src="<?=base_url('assets/images/patner/bpr.jpg');?>" alt="Topflytech Logo"></a>
                        </div>
                        <!--/ client #3 -->
                   
                    <!--/ carousel -->
               
            </section>
            <!--/ END Lovely Client -->

            <!-- START To Top Scroller -->
            <a href="#" class="totop animation" data-toggle="waypoints totop" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="50%"><i class="ico-angle-up"></i></a>
            <!--/ END To Top Scroller -->
        </section>
        <!--/ END Template Main -->

<?php $this->load->view($footer);?>

<!-- Plugins and page level script : optional -->
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/owl/js/owl.carousel.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/greensock.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/layerslider.transitions.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/javascript/frontend/home/home-v1.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/javascript/frontend/pages/portfolio.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/shuffle/js/jquery.shuffle.js"></script>
<script type="text/javascript" src="<?=base_url();?>assets/front-end/plugins/magnific/js/jquery.magnific-popup.js"></script>
<!--/ Plugins and page level script : optional -->
